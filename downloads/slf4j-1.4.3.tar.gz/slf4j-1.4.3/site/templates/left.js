
document.write('<p class="menu_header">SLF4J Project</p>');
document.write('<p><a href="index.html">Introduction</a>');
document.write('<a href="news.html">News</a>');
document.write('<a href="docs.html">Documentation</a>');
document.write('<a href="license.html">License</a>');
document.write('<a href="download.html">Download</a>');

document.write('<a href="svn.html">Source Repository</a>');
document.write('<a href="mailing-lists.html">Mailing Lists</a>');
document.write('<a href="bug-reporting.html">Bug Reporting</a>');

document.write('<p class="menu_header">Native implementations</p>');
document.write('<a href="http://logback.qos.ch/">Logback</a>');
document.write('<a href="http://www.x4juli.org">x4juli</a>');
document.write('<p class="menu_header">Wrapped implementations</p>');
document.write('<a href="api/org/slf4j/impl/JDK14LoggerAdapter.html">JDK14</a>');
document.write('<a href="api/org/slf4j/impl/Log4jLoggerAdapter.html">Log4j</a>');
document.write('<a href="api/org/slf4j/impl/SimpleLogger.html">Simple</a>');
document.write('<a href="http://simple-log.dev.java.net/">Simple-log</a>');
document.write('</p>');



