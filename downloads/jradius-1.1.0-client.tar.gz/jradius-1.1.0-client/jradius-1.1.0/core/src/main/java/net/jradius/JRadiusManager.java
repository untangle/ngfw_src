package net.jradius;

public interface JRadiusManager
{
    public abstract void start();
    public abstract void stop();
}