These patches are not supported. They are provided here only for your
conveinience. If you port a patch to a newer version of jCIFS please
resubmit it to the mailing list.

LargeReadWrite.patch:

This patch adds two SMBs that supposedly improves read and write
performance considerably. Unfortunately it's not crystal clear
that all implementation properly support the commands. Note that
in addition to this patch an '& 0xFFFF' needs to be added in
SmbTransport.java:doRecv:~437 to appear as:

  int size = Encdec.dec_uint16be( BUF, 2 ) & 0xFFFF;

although this change has been made in 1.2.7.
