import jcifs.smb.*;

public class ListACL {

    public static void main( String[] args ) throws Exception {
        if (args.length < 1) {
            System.err.println( "usage: ListACL <smburl>\n" );
            return 0;
        }
        SmbFile f = new SmbFile( args[0] );
        ACE[] acl = f.getSecurity();
        for (int i = 0; i < acl.length; i++) {
            System.out.println( acl[i] );
        }
    }
}
