package org.jabsorb.serializer;

import java.util.ArrayDeque;
import java.util.Deque;

/**
 * Context that holds the marshalling mode for a given thread.
 * Based on the mode, different behavior of marshall/unmarshall can be controlled.
 */
public class MarshallingModeContext {

    // Main context (inheritable across child threads)
    private static final InheritableThreadLocal<Deque<MarshallingMode>> current = new InheritableThreadLocal<Deque<MarshallingMode>>() {
        @Override
        protected Deque<MarshallingMode> initialValue() {
            return new ArrayDeque<>();
        }
        @Override
        protected Deque<MarshallingMode> childValue(Deque<MarshallingMode> parentValue) {
            return new ArrayDeque<>(parentValue);
        }
    };

    /**
     * Pushes the value on to the stack
     * @param mode
     */
    public static void push(MarshallingMode mode) {
        current.get().push(mode);
    }

    /**
     * peeks the current MarshallingMode value from the stack. Defaults to JABSORB if not context was set.
     * @return
     */
    public static MarshallingMode get() {
        Deque<MarshallingMode> stack = current.get();
        if (stack == null || stack.isEmpty()) {
            // default to JABSORB
            return MarshallingMode.JABSORB;
        }
        MarshallingMode mode = stack.peek();
        return mode != null ? mode : MarshallingMode.JABSORB;
    }

    /**
     * pops out the value from the stack
     */
    public static void pop() {
        Deque<MarshallingMode> stack = current.get();
        if (stack != null && !stack.isEmpty()) {
            stack.pop();
        }
    }

    /**
     * clears the stack
     */
    public static void clear() {
        current.remove();
    }
}
