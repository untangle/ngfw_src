                                  README

                        The Alloy Look&Feel Version 1.4.4

                 
 FILES

    readme.txt       - this file
    alloy.jar        - jar-file containing the Alloy Look&Feel
    doc/             - directory containing the documentation for the Alloy Look&Feel
    doc/index.html   - starting point for the documentation


 PREREQUISITES

  - Java 1.3 or later (available at http://java.sun.com/j2se/)
 
 KNOWN ISSUES

  - Missing support for scrollable tabs on tabbed panes
  
 
 SUPPORT ADDRESS

  - For feedback please contact us at support@incors.com



We hope you enjoy working with the Alloy Look&Feel!


------------------------------------------------------------------------
The Alloy Look&Feel was created by INCORS GMBH
Copyright (c) 2002-2003 by INCORS GmbH, Simon-Dach-Str. 21, 10245 Berlin, GERMANY

Java and all Java-based trademarks and logos are trademarks or 
registered trademarks of Sun Microsystems, Inc. in the United States 
and other countries.
