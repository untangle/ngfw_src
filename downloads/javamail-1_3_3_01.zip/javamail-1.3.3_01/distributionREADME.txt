DistributionREADME for JavaMail Software Distribution.

1. DISTRIBUTION BY DEVELOPERS.  Subject to the terms and conditions of
the Software License Agreement and the obligations, restrictions, and
exceptions set forth below, You may reproduce and distribute the
Software, provided that:

(a) you distribute the Software complete and unmodified and only
bundled as part of Your applets and applications ("Programs"),

(b) your Programs add significant and primary functionality to the
Software

(c) you distribute Software for the sole purpose of running your
Programs,

(d) you do not distribute additional software intended to replace any
component(s) of the Software,

(e) you do not remove or alter any proprietary legends or notices
contained in or on the Software.

(f) you only distribute the Software subject to a license agreement
that protects Sun's interests consistent with the terms contained in
this Agreement, and

(g) you agree to defend and indemnify Sun and its licensors from and
against any damages, costs, liabilities, settlement amounts and/or
expenses  (including attorneys' fees) incurred in connection with any
claim, lawsuit or action by any third party that arises or results from
the use or distribution of any and all Programs and/or Software.
