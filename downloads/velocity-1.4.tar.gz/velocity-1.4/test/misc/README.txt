$Id: README.txt,v 1.5 2001/03/12 02:09:19 jon Exp $

This directory contains some misc tests for you to ponder over.

compile.sh: This script will compile a .vm file into a .class file.
            Note: at the current time, this code is not working.
            Usage: ./compile.sh ../templates/test.vm

dump.sh: This script will dump out a text representation of the AST.
         Usage: ./dump.sh ../templates/test.vm

test.sh: This script is used for command line testing of .vm files.
         Note: this script is not a replacement for the core testing
         suite. It is simply a convinence script/class for the developers.

thanks!

- The Velocity Team
