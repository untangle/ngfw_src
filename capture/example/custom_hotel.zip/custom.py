from uvm.settings_reader import get_nodeid_settings
from mod_python import apache
from mod_python import util
from uvm import Uvm
import cgi

# When you include a custom.py file in your custom captive portal zip file
# you get full control over the capture and authentication process.

# When the captive portal intercepts traffic and a capture page needs to
# be displayed, our main handler will call your index function and will
# pass you a bunch of parameters you can use to build your custom page:
#
# req - this is the apache request object
# rawpath - this is the full path to where the custom files are stored
#   and it will include the trailing backslash
#   e.g.: /usr/share/untangle/web/capture/custom_6/
# webpath - this is the relative path from which images and other
#   linked content can be specified and includes trailing backslash
#   e.g.: /capture/custom_6/
# appid - each instance of captive portal is assigned a unique appid
#   value that you MUST include as a parameter to the custom_handler
#   so the mod_python scripts know which instance to work with
#   e.g.: 6
# host - this is the host from the original HTTP request that resulted
#   in the captive page display
#   e.g.: www.yahoo.com
# uri - this is the path from the original HTTP request that resulted
#   in the captive page display
#   e.g.: /some/page/or/something/content.html
#
# In our example below we create a simple page with a form where the hotel
# guest can enter their name and room number.  Note that the POST handler
# is set to the parent captive portal handler, and we pass the appid so it
# knows which instance of captive portal is calling.  Our example doesn't
# need the rawpath but we do use the webpath to include a spiffy image
# and page icon.  We hide the original host and uri in the form so we can
# redirect the user to their original destination after authentication.

def index(req,rawpath,webpath,appid,host,uri):

    page = "<HTML><HEAD>"
    page += "<META http-equiv='Content-Type' content='text/html; charset=UTF-8' />"
    page += "<SCRIPT type='text/javascript'> function FocusOnInput() { document.getElementById('guest').focus(); } </SCRIPT>"
    page += "<LINK REL='icon' TYPE='image/png' HREF='" + webpath + "pageicon.png'>"
    page += "<TITLE>Hotel Wonderful</TITLE>"
    page += "</HEAD><BODY ONLOAD='FocusOnInput()'>"
    page += "<H1>Free Internet for Hotel Guests</H1>"
    page += "<IMG src='" + webpath + "hotel.jpg'></IMG>"
    page += "<P><H3>Please enter your last name and room number and click Connect.</H3></P>"
    page += "<FORM AUTOCOMPLETE='OFF' METHOD='POST' ACTION='/capture/handler.py/custom_handler?appid=" + appid + "'>"
    page += "<TABLE BORDER=0 CELLPADDING=8>"
    page += "<TR><TD>Last Name</TD><TD><INPUT WIDTH=80 TYPE='text' NAME='guest' ID='guest'></INPUT></TD></TR>"
    page += "<TR><TD>Room Number</TD><TD><INPUT WIDTH=80 TYPE='text' NAME='suite' ID='suite'></INPUT></TD></TR>"
    page += "</TABLE>"
    page += "<INPUT TYPE='hidden' NAME='host' ID='host' VALUE='" + host + "'></INPUT>"
    page += "<INPUT TYPE='hidden' NAME='uri' ID='uri' VALUE='" + uri + "'></INPUT>"
    page += "<P><BUTTON TYPE='submit' NAME='submit' ID='submit' TITLE='Connect'>Connect</BUTTON></P>"
    page += "</FORM>"
    page += "</BODY></HTML>"

    req.content_type = "text/html"
    req.write(page)

# When our parent post handler gets the form defined above, it will call
# your handler function passing many of the same arguments described above.
# In our example, we don't really do any validation of the form data.  We
# simply pass the client IP address and guest name to the userLogin
# function which allows traffic for that client to begin flowing through
# captive portal.  This is the function where you can get really creative.
# A real hotel might do a database lookup to make sure the name and room
# number match.  If not, instead of calling userLogin and doing the redirect
# you might return the capture page again, including an error message asking
# them to try again.  The sky is the limit here.  You can do any kind of
# validation or authentication you want, and call the userLogin function
# to allow access once the access requirements have been met.

def handler(req,rawpath,webpath,appid):

    # get the network address of the client
    address = req.get_remote_host(apache.REMOTE_NOLOOKUP,None)

    # grab the form fields from the post data
    guest = req.form['guest']
    suite = req.form['suite']
    host = req.form['host']
    uri = req.form['uri']

    # first we get the uvm context
    context = Uvm().getUvmContext()
    if (context == None):
        raise Exception("The uvm context could not be obtained")

    # now we use the uvm context to get the captive portal node instance
    # note that we pass the appid so we get a reference to the correct instance
    capture = context.nodeManager().node(long(appid))
    if (capture == None):
        raise Exception("The uvm node manager could not locate the capture node instance")

    # we also want the node settings so we can check for a custom redirect target
    settings = get_nodeid_settings(long(appid))
    if (settings == None):
        raise Exception("Unable to load capture node settings")

    # call the node to login the user which will tell captive portal
    # to allow all traffic from the client address specified
    capture.userLogin(address,str(guest))

    # if a redirect URL is configured we send the user to that location
    if (len(settings['redirectUrl']) != 0) and (settings['redirectUrl'].isspace() == False):
        target = str(settings['redirectUrl'])
    # no redirect URL is configured so send the user to the originally requested page
    else:
        # if the host or uri are empty we just return a simple success page
        if ((host == 'Empty') or (uri == 'Empty')):
            page = "<HTML><HEAD><TITLE>Login Success</TITLE></HEAD><BODY><H1>Login Success</H1></BODY></HTML>"
            return(page)
        else:
            target = str("http://" + host + uri)

    util.redirect(req, target)
