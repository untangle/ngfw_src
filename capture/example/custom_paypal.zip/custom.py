from mod_python import apache
from mod_python import util
from mod_python import Session
from uvm import Uvm
import cgi
import simplejson as json
from datetime import datetime
import urllib
import urllib2
import random
import time


# PayPal sandbox URL.This URL's IP address along with www.paypalobjects.com corresponding IP address must be added into Captive Portal, Passed Hosts, Pass Listed Server Addresses
PAYPAL_URL="https://www.sandbox.paypal.com"

#the button should be created by the user which receives the payment  The URL of this page must be set in the button to receive notifications
#For the cancelCheckot notification: http://[Untangle box IP]/capture/custom_[n]/custom.py/cancelCheckout
#For the finish checkount notification: http://[Untangle box IP]/capture/custom_[n]/custom.py/finishCheckout
BUTTON_ID="VMSV6QK9LA3HS"

# The user which receives the payments must set Auto Return to Website Payments to On
# and set the return URL similar to the finish checkout notification: http://[Untangle box IP]/capture/custom_[n]/custom.py/finishCheckout
# Payment Data Transfer must be set to On and the generated identity token must be used below

PDT_IDENTITY_TOKEN='m_f6twlH32gWmylq65npQkDvKNDCdhX6PjfGBycZu5f0ynCfjQrN4iSLNLG'

# General Note: While this custom page is active be aware that admin actions in the WebUI on Local Directory can overwrite
# new users created by this page if those users are created while the admin is performing actions in the WebUI

def buyNowButton( url, buttonid):
    retVal ='<form action="%s/cgi-bin/webscr" method="post" target="_top">' % url
    retVal +='<input type="hidden" name="cmd" value="_s-xclick">'
    retVal +='<input type="hidden" name="hosted_button_id" value="%s">' % buttonid
    retVal +='<input type="image" src="%s/en_US/i/btn/btn_buynowCC_LG.gif" border="0" name="submit" alt="PayPal - The safer, easier way to pay online!">' % url
    retVal +='<img alt="" border="0" src="%s/en_US/i/scr/pixel.gif" width="1" height="1">' % url
    retVal +='</form>'
    return retVal
    
def loginForm(appid, host, uri, user=None, password=None):
    page = "<FORM AUTOCOMPLETE='OFF' METHOD='POST' ACTION='/capture/handler.py/custom_handler?appid=" + appid + "'>"
    page += "<TABLE BORDER=0 CELLPADDING=8>"
    if not user:
        page += "<TR><TD>Username</TD><TD><INPUT WIDTH=80 TYPE='text' NAME='username' ID='username'></INPUT></TD></TR>"
    else:        
        page += "<TR><TD>Username</TD><TD><INPUT WIDTH=80 TYPE='text' NAME='username' ID='username' value='%s'></INPUT></TD></TR>" % user
    if not password:
        page += "<TR><TD>Password</TD><TD><INPUT WIDTH=80 TYPE='password' NAME='pwd' ID='pwd'></INPUT></TD></TR>"
    else:
        page += "<TR><TD>Password</TD><TD><INPUT WIDTH=80 TYPE='password' NAME='pwd' ID='pwd' value='%s'></INPUT></TD></TR>" % password
    page += "</TABLE>"
    page += "<INPUT TYPE='hidden' NAME='host' ID='host' VALUE='" + host + "'></INPUT>"
    page += "<INPUT TYPE='hidden' NAME='uri' ID='uri' VALUE='" + uri + "'></INPUT>"
    page += "<P><BUTTON TYPE='submit' NAME='submit' ID='submit' TITLE='Login' value='Login'>Login</BUTTON></P>"
    page += "</FORM>"
    return page

    


# When you include a custom.py file in your custom captive portal zip file
# you get full control over the capture and authentication process.

# When the captive portal intercepts traffic and a capture page needs to
# be displayed, our main handler will call your index function and will
# pass you a bunch of parameters you can use to build your custom page:
#
# req - this is the apache request object
# rawpath - this is the full path to where the custom files are stored
#   and it will include the trailing backslash
#   e.g.: /usr/share/untangle/web/capture/custom_6/
# webpath - this is the relative path from which images and other
#   linked content can be specified and includes trailing backslash
#   e.g.: /capture/custom_6/
# appid - each instance of captive portal is assigned a unique appid
#   value that you MUST include as a parameter to the custom_handler
#   so the mod_python scripts know which instance to work with
#   e.g.: 6
# host - this is the host from the original HTTP request that resulted
#   in the captive page display
#   e.g.: www.yahoo.com
# uri - this is the path from the original HTTP request that resulted
#   in the captive page display
#   e.g.: /some/page/or/something/content.html
#
# In our example below we create a simple page with a form where the hotel
# guest can enter their name and room number.  Note that the POST handler
# is set to the parent captive portal handler, and we pass the appid so it
# knows which instance of captive portal is calling.  Our example doesn't
# need the rawpath but we do use the webpath to include a spiffy image
# and page icon.  We hide the original host and uri in the form so we can
# redirect the user to their original destination after authentication.\

def index(req,rawpath,webpath,appid,host,uri):
    session = Session.Session(req)
    if session.is_new():
        session['rawpath']=rawpath
        session['webpath']=webpath
        session['appid']=appid
        session['host']=host
        session['uri']=uri
        session.save()
    page = "<HTML><HEAD>"
    page += "<META http-equiv='Content-Type' content='text/html; charset=UTF-8' />"
    page += "<body>"
    page += "<h2>Login or buy 1 Day pass<h2>"
    page += loginForm(appid,host,uri)
    page += "<br/><br/>"
    page += buyNowButton(PAYPAL_URL, BUTTON_ID)
    page += "<body>"
    page += "</html>"
    req.content_type = "text/html"
    req.write(page)
    

def cancelCheckout(req):
    session = Session.Session(req)
    if not session.is_new():
        index(req,session['rawpath'],session['webpath'],session['appid'],session['host'],session['uri'])
    else:
        page = "<html><body><H1>Cancel checkout </H1></body></html>"
        req.content_type = "text/html"
        req.write(page)
    
def generatePassword(length):
    return ''.join(map(lambda x:random.choice('ABCDEFGHIJKLMNOPRSTUVXYZ0123456789'), range(length)))

def finishCheckout(req):        
    page = "<html><body><H1>Checkout finished</H1></body></html>"
    params = util.FieldStorage(req)
    tx=params.get("tx","")
    if len(tx) > 0:
        url = "%s/cgi-bin/webscr" % PAYPAL_URL
        data = urllib.urlencode({'tx': tx,'at':PDT_IDENTITY_TOKEN,'cmd':'_notify-synch'})
        results = urllib2.urlopen(url, data)
        html = results.read()
        page +='<br/>';
        if html.find('SUCCESS') != -1:
            values = html.split('\n')
            for value in values:
                if value.find('payer_email') != -1:
                    parts = value.split('=')
                    email = parts[len(parts)-1]
                    email = urllib.unquote(email).decode('utf8')
                    context = Uvm().getUvmContext()
                    if not context:
                        raise Exception("The uvm context could not be obtained")
                    localDirectory = context.localDirectory()
                    if not localDirectory:
                        raise Exception("The uvm node manager could not locate the local directory instance")
                    pwd = generatePassword(6)
                    userToRegister={"email": "%s"%email, "firstName":"", "lastName":"", "password":"%s"%pwd, "username":"%s"%email, "expirationTime":int((time.time() + 86400)*1000), "javaClass":"com.untangle.uvm.LocalDirectoryUser"}
                    if not localDirectory.userExists(userToRegister):
                        localDirectory.addUser(userToRegister)
                        page += "<b>Login credentials</b> <br/><br/>"
                        page += "Username:<b>%s</b><br/>" % email
                        page += "Password:<b>%s</b><br/><br/>" % pwd
                        page += "Save the credentials and press the login button below to access the Internet<br/><br/>"
                    else:
                        updatedUser={"email": "%s"%email, "username":"%s"%email, "expirationTime":int((time.time() + 86400)*1000), "javaClass":"com.untangle.uvm.LocalDirectoryUser"}
                        localDirectory.updateUser(updatedUser)

                    session = Session.Session(req)
                    try:
                        page += loginForm(session['appid'],session['host'],session['uri'], email, pwd)
                    except KeyError:
                        pass
        else:
            page += html
    req.content_type = "text/html"
    req.write(page)

     
    
# When our parent post handler gets the form defined above, it will call
# your handler function passing many of the same arguments described above.
def handler(req,rawpath,webpath,appid, loginMap={}):

    # get the network address of the client
    address = req.get_remote_host(apache.REMOTE_NOLOOKUP,None)

    # grab the form fields from the post data
    uname=req.form['username'].value
    pwd = req.form['pwd'].value
    host = req.form['host'].value
    uri = req.form['uri'].value

    # first we get the uvm context
    context = Uvm().getUvmContext()
    if not context:
        raise Exception("The uvm context could not be obtained")

    # now we use the uvm context to get the captive portal node instance
    # note that we pass the appid so we get a reference to the correct instance
    capture = context.nodeManager().node(long(appid))
    if not capture:
        raise Exception("The uvm node manager could not locate the capture node instance")

    captureAuth = capture.userAuthenticate(address, uname, pwd)
        
    # redirect the now authenticated user to the page the originally requested
    target = str("http://" + host + uri)
    util.redirect(req, target)
