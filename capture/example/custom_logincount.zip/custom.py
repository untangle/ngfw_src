from uvm.settings_reader import get_nodeid_settings
from mod_python import apache
from mod_python import util
from uvm import Uvm
import cgi
import simplejson as json
from datetime import datetime

#Login rules. For this example the users which appear in the checkedUsers list will be allowed to login
#for maximum 3 times / 12 h interval

maxLogins=3 # maximum number of logins per time interval
timeInterval=43200 # the time interval in seconds for which the login counts are checked.Max value is 86399.
notCheckedUsers=[] # the users for which checking is NOT enforced. By default all users are checked

# As the custom handler is reloaded using imp.load_module at each request the lines below prevent
# the loginMap ( which contains for each user the user's login count and first login timestamp/timeinterval) to be re-initialized
try:
    loginMap
except NameError:
    loginMap={}

# When you include a custom.py file in your custom captive portal zip file
# you get full control over the capture and authentication process.

# When the captive portal intercepts traffic and a capture page needs to
# be displayed, our main handler will call your index function and will
# pass you a bunch of parameters you can use to build your custom page:
#
# req - this is the apache request object
# rawpath - this is the full path to where the custom files are stored
#   and it will include the trailing backslash
#   e.g.: /usr/share/untangle/web/capture/custom_6/
# webpath - this is the relative path from which images and other
#   linked content can be specified and includes trailing backslash
#   e.g.: /capture/custom_6/
# appid - each instance of captive portal is assigned a unique appid
#   value that you MUST include as a parameter to the custom_handler
#   so the mod_python scripts know which instance to work with
#   e.g.: 6
# host - this is the host from the original HTTP request that resulted
#   in the captive page display
#   e.g.: www.yahoo.com
# uri - this is the path from the original HTTP request that resulted
#   in the captive page display
#   e.g.: /some/page/or/something/content.html
#
# In our example below we create a simple page with a form where the hotel
# guest can enter their name and room number.  Note that the POST handler
# is set to the parent captive portal handler, and we pass the appid so it
# knows which instance of captive portal is calling.  Our example doesn't
# need the rawpath but we do use the webpath to include a spiffy image
# and page icon.  We hide the original host and uri in the form so we can
# redirect the user to their original destination after authentication.

def index(req,rawpath,webpath,appid,host,uri,errorText=None):

    page = "<HTML><HEAD>"
    page += "<META http-equiv='Content-Type' content='text/html; charset=UTF-8' />"
    page += "<SCRIPT type='text/javascript'> function FocusOnInput() { document.getElementById('guest').focus(); } </SCRIPT>"
    page += "<LINK REL='icon' TYPE='image/png' HREF='" + webpath + "pageicon.png'>"
    page += "<TITLE>Custom login</TITLE>"
    page += "</HEAD><BODY ONLOAD='FocusOnInput()'>"
    page += "<H1>Custom login</H1>"
    if errorText and len(errorText) > 0:
        page += "<P><H4><FONT color=\"red\">%s</font></H4></P>" % errorText
    page += "<FORM AUTOCOMPLETE='OFF' METHOD='POST' ACTION='/capture/handler.py/custom_handler?appid=" + appid + "'>"
    page += "<TABLE BORDER=0 CELLPADDING=8>"
    page += "<TR><TD>Username</TD><TD><INPUT WIDTH=80 TYPE='text' NAME='username' ID='username'></INPUT></TD></TR>"
    page += "<TR><TD>Password</TD><TD><INPUT WIDTH=80 TYPE='password' NAME='pwd' ID='pwd'></INPUT></TD></TR>"
    page += "</TABLE>"
    page += "<INPUT TYPE='hidden' NAME='host' ID='host' VALUE='" + host + "'></INPUT>"
    page += "<INPUT TYPE='hidden' NAME='uri' ID='uri' VALUE='" + uri + "'></INPUT>"
    page += "&nbsp;&nbsp;&nbsp;&nbsp;<BUTTON TYPE='submit' NAME='submit' ID='submit' TITLE='Login' value='Login'>Login</BUTTON></P>"
    page += "</FORM>"
    page += "</BODY></HTML>"

    req.content_type = "text/html"
    req.write(page)

#check if the user with the given username is allowed to log in
def checkLoginCount( uname):
    if uname not in notCheckedUsers and uname in loginMap:
        loginCount = loginMap[uname][0]
        firstIntervalLogin = loginMap[uname][1]
        loginCount += 1
        delta = datetime.now() - firstIntervalLogin
        if loginCount > maxLogins and delta.days==0 and delta.seconds < timeInterval:
            return False
    return True

#updates the login count for the given user
def updateLoginCount( uname):
    if uname not in notCheckedUsers:
        if uname in loginMap:
            loginCount = loginMap[uname][0]
            firstIntervalLogin = loginMap[uname][1]
            delta = datetime.now()-firstIntervalLogin
            if delta.days > 0 or ( delta.days == 0 and delta.seconds >= timeInterval):
                loginMap[uname]=(1, datetime.now())
            else:
                loginMap[uname]=(loginCount + 1, firstIntervalLogin)
        else:
            loginMap[uname]=(1,datetime.now())

# When our parent post handler gets the form defined above, it will call
# your handler function passing many of the same arguments described above.
def handler(req,rawpath,webpath,appid, loginMap={}):

    # get the network address of the client
    address = req.get_remote_host(apache.REMOTE_NOLOOKUP,None)

    # grab the form fields from the post data
    uname=req.form['username'].value
    pwd = req.form['pwd'].value
    host = req.form['host'].value
    uri = req.form['uri'].value

    # first we get the uvm context
    context = Uvm().getUvmContext()
    if not context:
        raise Exception("The uvm context could not be obtained")

    # now we use the uvm context to get the captive portal node instance
    # note that we pass the appid so we get a reference to the correct instance
    capture = context.nodeManager().node(long(appid))
    if not capture:
        raise Exception("The uvm node manager could not locate the capture node instance")
    if checkLoginCount(uname):
        captureAuth = capture.userAuthenticate(address, uname, pwd)
        updateLoginCount(uname)
    else:
        return index(req,rawpath,webpath,appid,host,uri,"Login count exceeded !")

    # we also want the node settings so we can check for a custom redirect target
    settings = get_nodeid_settings(long(appid))
    if (settings == None):
        raise Exception("Unable to load capture node settings")

    # if a redirect URL is configured we send the user to that location
    if (len(settings['redirectUrl']) != 0) and (settings['redirectUrl'].isspace() == False):
        target = str(settings['redirectUrl'])
    # no redirect URL is configured so send the user to the originally requested page
    else:
        # if the host or uri are empty we just return a simple success page
        if ((host == 'Empty') or (uri == 'Empty')):
            page = "<HTML><HEAD><TITLE>Login Success</TITLE></HEAD><BODY><H1>Login Success</H1></BODY></HTML>"
            return(page)
        else:
            target = str("http://" + host + uri)

    util.redirect(req, target)
