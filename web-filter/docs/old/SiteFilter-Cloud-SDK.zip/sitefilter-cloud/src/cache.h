/* Copyright 2008 eSoft, Inc.
 * All Rights Reserved.
 * Licensed under the terms of the eSoft SiteFilter Cache Reference EULA.
 *
 * This code uses the Boost libraries.
 * For more information see: http://www.boost.org/doc/
 */

#ifndef CACHE_H
#define CACHE_H

#include <vector>
#include <deque>
#include <string>
#include <memory>
#include <boost/functional/hash.hpp>
#include "allocator.h"
#include "url.h"

namespace eSoft {

// The url_cache stores a collection of domain information.  Each domain has a
// pointer to a collection of path information.
// The STL deque and vector collections are used here in order to save
// memory space.  The STL map would provide more efficient insert and delete
// but at the cost of three pointers per item.
// Hashes are also used to save space. Instead of storing entire URL strings,
// the string is converted to a number and that number is stored instead.
// The danger is that more than one URL may convert to the same number, resulting
// in cache responses with the wrong category.
// Using a larger hash size and/or different hash functions makes this more
// unlikely.
// NOTE: Simply redefining path_hash_t as a larger integer will not work. A larger
// hash function must be chosen as well. The 64-bit MurmurHash works well and is
// included.

#if 1
typedef std::size_t path_hash_t;
typedef std::size_t domain_hash_t;
inline
std::size_t make_hash(const std::string &s)
{
	return boost::hash_value(s);
}
#else
# include "murmur-hash2-64.hpp"
typedef uint64_t path_hash_t;
typedef uint64_t domain_hash_t;
inline
uint64_t make_hash(const std::string &s)
{
	return MurmurHash64B(s.data(), s.length(), 0);
}
#endif

// The declarations for each path entry and the path collection.
struct info_t {
	static const unsigned max_categories = 4;
	uint16_t info[max_categories];

	info_t()
	{ memset(&info, 0, sizeof(info)); }
	bool operator!()
	{
		return (info[0] & 0x7fff) == 0;
	}
};
inline
bool is_authoritative(const info_t &info)
{
	return info.info[0] & (1<<15);
}
inline
void mark_authoritative(info_t &info)
{
	info.info[0] |= (1<<15);
}

struct path_entry_t {
	path_hash_t hash;
	info_t info;
	time_t timestamp;

	explicit path_entry_t(path_hash_t x=0, const info_t &y=info_t(), time_t z=0)
	: hash(x), info(y), timestamp(z)
	{}
	bool operator<(const path_entry_t& x) const
	{ return hash < x.hash; }
	bool operator<(const path_hash_t x) const
	{ return hash < x; }
};
class path_list_t
: public std::vector<path_entry_t, tracking_pool_allocator<path_entry_t> >,
  public fast_pod_allocator< std::vector<path_entry_t, tracking_pool_allocator<path_entry_t> > >
{
public:
	typedef std::vector<path_entry_t, tracking_pool_allocator<path_entry_t> > _Parent;

	explicit path_list_t(int x) : _Parent(x) {}
};

// The declarations for each domain entry and the domain collection.
struct domain_entry_t {
	domain_hash_t hash;
	path_list_t* paths;

	explicit domain_entry_t(domain_hash_t x)
	: hash(x), paths(0)
	{}
	bool operator<(const domain_entry_t& x) const
	{ return hash < x.hash; }
	bool operator<(const domain_hash_t x) const
	{ return hash < x; }
};
typedef std::deque<domain_entry_t, tracking_pool_allocator<domain_entry_t> > domain_list_t;

// The URL cache itself, which contains the domain collection, which in turn
// contains a path collection.
class url_cache {
public:
	static const size_t max_categories = info_t::max_categories;
	static const int day_seconds = 60*60*24;

	url_cache()
	{}
	~url_cache();

	info_t lookup( const url &url ) const;
	void insert(
		const url &url,
		const info_t &info,
		time_t timestamp = time(0)
	);

	void clean_expired(time_t cutoff = time(0)-day_seconds);
	void clean_oldest_n(size_t n);

	const domain_list_t& get_domains() const
	{ return domains; }

private:
	domain_list_t domains;

private:
	url_cache(const url_cache&);
	url_cache& operator=(const url_cache&);

	const domain_list_t::const_iterator
	lookup_domain(
		const std::string& domain,
		bool& authority
	) const;

	const path_list_t::const_iterator
	lookup_path(
		const domain_list_t::const_iterator& d_pos,
		const std::string& path,
		bool& authority
	) const;
};

// These two classes are used for encoding and decoding category
// information from the data stored in the URL cache.
class category_encoder {
	info_t &result;
	unsigned idx;
	public:
	category_encoder(info_t &x)
		: result(x), idx(0)
	{
	}
	void operator()(unsigned id) {
		if( idx == info_t::max_categories )
			return;
		result.info[idx++] = (id & 0x7fff);
	}
};

class category_decoder {
	const info_t &info;
	unsigned idx;
	public:
	category_decoder(const info_t &x)
		: info(x), idx(0)
	{
	}
	unsigned operator()() {
		if( idx == info_t::max_categories )
			return 0;
		unsigned id = (info.info[idx++] & 0x7fff);
		return id;
	}
};

}; // namespace eSoft

#include "cache.hpp"
#endif
