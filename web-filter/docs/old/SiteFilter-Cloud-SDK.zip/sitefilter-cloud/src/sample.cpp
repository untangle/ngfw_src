/* Copyright 2008 eSoft, Inc.
 * All Rights Reserved.
 * Licensed under the terms of the eSoft SiteFilter Cache Reference EULA.
 */
#ifdef _WIN32
# include <winsock2.h>
# include <windows.h>
#else
# include <csignal>
# include <unistd.h>
#endif

#include <ctime>
#include <memory>
#include <iostream>
#include <fstream>
#include <string>
#include <utility>
#include <iterator>

#include "dia-cache.h"

#undef USE_BOOST_OPTIONS

#ifdef USE_BOOST_OPTIONS
# include <boost/program_options.hpp>
#endif

using namespace std;
using namespace eSoft;

string key("");
string serial("");
string host("");
bool async = false;

struct category_item {
	unsigned id;
	string name;

	bool operator< (const category_item &x) const
	{
		return id < x.id;
	}
	bool operator< (const unsigned x) const
	{
		return id < x;
	}
};


inline
istream& operator>>(istream &is, category_item &x)
{
	const unsigned max_line = 8192;
	is >> x.id;
	is.ignore(1, '\t');
	getline(is, x.name, '\t');
	is.ignore(max_line, '\n');
	return is;
}

inline
ostream& operator<<(ostream &os, const category_item &x)
{
	os << '{' << x.id << ',' << x.name << '}';
	return os;
}

vector<category_item> category_names;

const time_t hour_seconds( 60*60 );
const time_t alarm_interval(1);
time_t now( time(0) );

#ifdef USE_BOOST_OPTIONS
void do_options(int argc, char *argv[])
{
	// Boost option processing
	namespace po = boost::program_options;
	po::options_description desc("Allowed options");
	desc.add_options()
		("help", "produce help message")
		("sync", "use synchronous DIA")
		("async", "use asynchronous DIA")
		("key", po::value<string>(), "DIA key")
		("serial", po::value<string>(), "DIA serial")
		("host", po::value<string>(), "DIA host")
	;

	po::variables_map vm;

	try {
		po::store(po::parse_command_line(argc, argv, desc), vm);
		po::notify(vm);
	} catch(const boost::program_options::unknown_option &) {
		cerr << desc << '\n';
		exit(1);
	}

	if (vm.count("help")) {
		cerr << desc << '\n';
		exit(1);
	}
	if (vm.count("key"))
		key = vm["key"].as<string>();
	if (vm.count("serial"))
		serial = vm["serial"].as<string>();
	if (vm.count("host"))
		host = vm["host"].as<string>();
	if (vm.count("async"))
		async = true;
}
#else
struct opt_key {
	string  key;
	string  help_text;
	string& val;
	int arg_offset;
};
void do_options(const int argc, const char * const argv[])
{
	string help;
	string sync("sync");
	const opt_key keys[] = {
		{"help", "produce help message", help, 0},
		{"sync", "use synchronous DIA", sync, 0},
		{"async", "use asynchronous DIA", sync, 0},
		{"key", "DIA key", key, 1},
		{"serial", "DIA serial", serial, 1},
		{"host", "DIA host", host, 1}
	};
	const int keys_len = sizeof(keys) / sizeof(*keys);
	int arg_i;
	for(arg_i=1; arg_i<argc; ++arg_i) {
		int key_i;
		for(key_i=0; key_i<keys_len; ++key_i) {
			const opt_key& k(keys[key_i]);
			if(
				arg_i < argc - k.arg_offset
				&& argv[arg_i][0] == '-' && argv[arg_i][1] == '-'
				&& k.key == (argv[arg_i]+2)
			) {
				k.val = argv[arg_i+k.arg_offset];
				arg_i += k.arg_offset;
				break;
			}
		}
		if( key_i == keys_len )
			help = "--help";
	}
	if( help.length() ) {
		cerr << "Allowed options:\n";
		for(int key_i=0; key_i<keys_len; ++key_i) {
			const opt_key& k(keys[key_i]);
			cerr << "  --" << k.key;
			if( k.arg_offset )
				cerr << " arg";
			for(int s=0; s < 20-(int)k.key.length()-(4*k.arg_offset); ++s)
				cerr << ' ';
			cerr << k.help_text << '\n';
		}
		exit(1);
	}
	if( sync == "--async" )
		async = true;
}
#endif

inline
void load_category_names(const char *file)
{
	ifstream is(file);
	if( !is ) {
		cerr << "Failed to open " << file << endl;
		return;
	}
	copy(
		istream_iterator<category_item>(is),
		istream_iterator<category_item>(),
		back_inserter(category_names)
	);
}

inline
string get_category_name(unsigned id)
{
	if( id == 0 ) {
		return "Uncategorized";
	}

	vector<category_item>::iterator i(
		lower_bound(
			category_names.begin(), category_names.end(),
			id
		)
	);

	if( i != category_names.end() && id == i->id ) {
		return i->name;
	} else {
		ostringstream os;
		os << "Category " << id;
		return os.str();
	}
}

inline void process( const string &url, info_t info)
{
	int cats[url_cache::max_categories] = {0};
	generate_n(cats, url_cache::max_categories, category_decoder(info));
	cout << url << ": ";
	for(unsigned i=0; i<url_cache::max_categories; ++i) {
		if (i > 0 && cats[i] == 0)
			break;
		if (i>0)
			cout << ',' << ' ';
		cout << get_category_name( cats[i] );
	}
	cout << '\n';
}

#ifdef _WIN32
inline void sleep(unsigned x)
{
	Sleep(x*1000);
}
inline void start_timer()
{
	// FIXME: Not sure how to do this in a Windows console app!
	// Create a thread and message loop there I suppose.  What a pain!
}
inline void update_time()
{
	now = time(0);
}
inline bool wait_for_events(cached_dia &)
{
	// FIXME: Another thing I can't do in a Windows console app.
	return true;
}
#else
volatile sig_atomic_t time_update(true);
void sig_handler(int sig)
{
	if (sig == SIGALRM)
		time_update = true;
	alarm(alarm_interval);
}
inline void start_timer()
{
	signal(SIGALRM, &sig_handler);
	alarm(alarm_interval);
}
inline void update_time()
{
	if (time_update) {
		time_update = false;
		now = time(0);
	}
}
inline bool wait_for_events(cached_dia &dia)
{
	struct pollfd pfd = {0, POLLIN, 0};
	while(true) {
		if( dia.wait(&pfd, 1, 10) < 0 ) {
			dia.poll(&pfd, 1, 10 * 1000);
		}
		if( pfd.revents )
			break;
	}
	return true;
}
#endif

int main(int argc, char *argv[])
{
	// Limit the lookups to 100 every second.
	// This is important if sample input is from a file of URLs.
	// At some point, UDP DNS packets will overflow OS buffers and vanish.
	const unsigned limit_count(100);
	const time_t limit_interval(1);
	time_t limit_cleared(0);
	unsigned processed(0);

	time_t next_expiration(now + hour_seconds);

	do_options(argc, argv);
	// speed up streaming output while reading from a file.
	ios_base::sync_with_stdio(false);
	cin.tie(0);

	// Read the category.txt file for category names.
	load_category_names("categories.txt");

	// Set up a periodic timer.
	start_timer();

	// Set the cache size to 1 MB and select our cached_dia implementation.
	memory_limiter::limit(1*1024*1024);
	auto_ptr<cached_dia> dia;
	if (async)
		dia.reset( new cached_dia_async(key, serial, host) );
	else
		dia.reset( new cached_dia_sync(key, serial, host, 5) );

	// Processing loop. Read a URL from input, process it, output result.
	// Also keep track of time, check for congestion and run cache expiration.
	// Cheat a little on Unix we know fd 0 is standard input.
	string url;
	while( wait_for_events(*dia) && getline(cin, url) ) {
		update_time();
		if (now > next_expiration) {
			dia->clean_expired();
			next_expiration = now + hour_seconds;
		}
		if (now > limit_cleared+limit_interval) {
			limit_cleared = now;
			processed = 0;
		}
		if (++processed > limit_count) {
			cerr << "Waiting for congestion to clear" << endl;
			sleep(1);
		}
		try {
			process( url, dia->lookup(url) );
		} catch (const submit_error &e) {
			cerr << "error submitting '" << url << '\'' << '\'' << e.what() << '\'' << endl;
		}
		// Keep this for interactive use, remove it for faster speed.
		cout << flush;
	}
	return 0;
}
