/* Copyright 2008 eSoft, Inc.
 * All Rights Reserved.
 * Licensed under the terms of the eSoft SiteFilter Cache Reference EULA.
 *
 * This code uses the Boost libraries.
 * For more information see: http://www.boost.org/doc/
 */

#ifndef CACHE_HPP
#define CACHE_HPP

#include <algorithm>
#include <set>
#include <string>
#include <sstream>
#include "cache.h"
#include "dlog.h"

namespace eSoft {

using namespace std;

url_cache::~url_cache()
{
	// Clean up each domain's path collection pointer.
	for(
		domain_list_t::const_iterator d_pos = domains.begin();
		d_pos < domains.end();
		++d_pos
	) {
		delete d_pos->paths;
	}
}

// Attempt to find a matching hash in the domains collection.
// Start with the full domain, then remove subdomains and try again
// until nothing remains.
const domain_list_t::const_iterator
url_cache::lookup_domain(
	const string& domain,
	bool& authority
) const {
	const domain_list_t::const_iterator d_begin( domains.begin() );
	const domain_list_t::const_iterator d_end( domains.end() );
	const string::size_type ds_end( domain.length() );
	string::size_type ds_begin(0);

	while (true) {
		string d_str(domain, ds_begin, ds_end-ds_begin);
		domain_hash_t d_hash( make_hash( d_str ));
		DLOG2(d_str, d_hash);
		domain_list_t::const_iterator d_pos(
			lower_bound(d_begin, d_end, domain_entry_t(d_hash))
		);
		if (d_pos != d_end && d_pos->hash == d_hash)
			return d_pos;

		// It was not found on the first attempt
		// so it cannot be an exact match.
		authority = false;
		ds_begin = domain.find('.', ds_begin);
		if (ds_begin == string::npos)
			break;
		else
			++ds_begin;
	}
	return d_end;
}

// Attempt to find a matching hash in the path collection.
// Start with the full path, then remove subpaths and try again
// until nothing remains.
const path_list_t::const_iterator
url_cache::lookup_path(
	const domain_list_t::const_iterator& d_pos,
	const std::string& path,
	bool& authority
) const {
	const path_list_t::const_iterator p_begin( d_pos->paths->begin() );
	const path_list_t::const_iterator p_end( d_pos->paths->end() );
	string::size_type ps_end( path.length() );
	while (true) {
		string p_str(path, 0, max<size_t>(ps_end, 1U));
		path_hash_t p_hash( make_hash(p_str) );
		DLOG2(p_str, p_hash);
		const path_list_t::const_iterator p_pos(
			lower_bound( d_pos->paths->begin(), d_pos->paths->end(), path_entry_t(p_hash) )
		);
		if( p_pos != p_end && p_pos->hash == p_hash )
			return p_pos;

		// It was not found on the first attempt
		// so it cannot be an exact match.
		authority = false;
		if (ps_end == 0)
			break;
		ps_end = path.rfind('/', ps_end-1);
		if (ps_end == string::npos)
			break;
	}
	return p_end;
}

// Use lookup_domain and lookup_path to find the best matches and return
// the cached information, or return 0 if nothing is found.
info_t url_cache::lookup(const url &url) const
{
	bool authority(true);
	info_t info;

	const domain_list_t::const_iterator d_pos( lookup_domain(url.domain, authority) );
	if( d_pos != domains.end() ) {
		string path = url::lower_case(url::back_to_slash(url.path));
		const path_list_t::const_iterator p_pos( lookup_path(d_pos, path, authority) );
		if( p_pos != d_pos->paths->end() ) {
			info = p_pos->info;
		}
	}
	if (authority)
		mark_authoritative(info);
	return info;
}

// Insert a new entry into the cache, or change an existing entry if it
// already exists.
void url_cache::insert(
	const url &url,
	const info_t &info,
	time_t timestamp
) {
	string path = url::lower_case(url::back_to_slash(url.path));
	// Find the domain if it exists.
	domain_hash_t d_hash( make_hash(url.domain) );
	domain_list_t::iterator d_pos(
		lower_bound(domains.begin(), domains.end(), domain_entry_t(d_hash))
	);
	DLOG2(url.domain, d_hash);
	path_hash_t p_hash( make_hash(path) );
	path_list_t::iterator p_pos;
	DLOG2(path, p_hash);
	DLOG1(info);

	if( d_pos != domains.end() && d_pos->hash == d_hash ) {
		// If the domain was found, find the path.
		p_pos = lower_bound(
			d_pos->paths->begin(), d_pos->paths->end(), path_entry_t(p_hash)
		);
		// The path is not found, so insert one.
		if( p_pos == d_pos->paths->end() || p_pos->hash != p_hash ) {
			p_pos = d_pos->paths->insert(p_pos, path_entry_t(p_hash, info, timestamp));
			return;
		}
	} else {
		// The domain was not found so insert one.
		d_pos = domains.insert(d_pos, domain_entry_t(d_hash));
		try {
			// And of course, no paths to search, so add a new path collection with
			// one new entry.
			d_pos->paths = new path_list_t(1);
			p_pos = d_pos->paths->begin();
			p_pos->hash = p_hash;
			p_pos->timestamp = timestamp;
		} catch (bad_alloc) {
			// Undo the domain addition if memory runs out while adding a new path.
			domains.erase(d_pos);
			throw;
		}
	}

	p_pos->info = info;
}

// Clean up cache entries with a timestamp older than the cutoff.
// This should be called periodically, perhaps once a day or once a week.
// This function is expensive because it scans the entire collection of
// domains and paths, and the deletions cause a lot of data movement in
// the collections.
void url_cache::clean_expired(time_t cutoff)
{
	domain_list_t::iterator d_pos( domains.begin() );
	while( d_pos != domains.end() ) {
		path_list_t& paths = *(d_pos->paths);
		path_list_t::iterator p_pos( paths.begin() );
		while( p_pos != paths.end() ) {
			if (p_pos->timestamp < cutoff) {
				p_pos = paths.erase(p_pos);
			} else {
				++p_pos;
			}
		}
		if (paths.empty()) {
			delete d_pos->paths;
			d_pos = domains.erase(d_pos);
		} else {
			++d_pos;
		}
	}
}

namespace details {
	// These need to be outside the clean_oldest_n function, but should not
	// be global, so they are in this details namespace.
	typedef std::pair<domain_list_t::const_iterator,path_list_t::const_iterator> dp_t;
	typedef std::pair<size_t,size_t> dp_index_t;
	struct dp_by_age {
		dp_t dp;

		dp_by_age(dp_t dp) : dp(dp)
		{}
		bool operator<(const dp_by_age& x) const
		{ return dp.second->timestamp > x.dp.second->timestamp; }
	};
};

// clean_oldest_n removes the n oldest items from the cache.
// This should be called whenever a bad_alloc exception is returned during
// an insert operation.  It will free up memory to be used for the insert.
// This operation is complicated.  It first builds a set of all entries, ordered
// by age.  Then it takes the first n items of the set to build a list of items
// to erase.  Then it erases those items.
// This function is expensive because it scans the entire collection of
// domains and paths, and the deletions cause a lot of data movement in
// the collections.
// Because of the expense, it is a good idea to use a large value of n,
// 1000 or more (depending on the cache size).
void url_cache::clean_oldest_n(size_t n)
{
	using namespace details;
	// Using a multiset because duplicate timestamps may occur.
	typedef multiset<dp_by_age> age_index_t;
	age_index_t age_index;
	set<dp_index_t> erase_list;

	for(
		domain_list_t::const_iterator d_pos = domains.begin();
		d_pos != domains.end();
		++d_pos
	) {
		const path_list_t& paths = *(d_pos->paths);
		for(
			path_list_t::const_iterator p_pos = paths.begin();
			p_pos != paths.end();
			++p_pos
		) {
			age_index.insert( dp_t(d_pos, p_pos) );
		}
	}

	age_index_t::const_iterator age_p( age_index.begin() );
	const age_index_t::const_iterator age_end( age_index.end() );
	const domain_list_t::const_iterator d_begin( domains.begin() );
	for(
		size_t i=0;
		i<n && age_p != age_end;
		++age_p, ++i
	) {
		const path_list_t::const_iterator p_begin( age_p->dp.first->paths->begin() );
		erase_list.insert( dp_index_t(age_p->dp.first - d_begin, age_p->dp.second - p_begin) );
	}

	size_t d_last = 0;
	size_t d_correct = 0;
	size_t p_correct = 0;
	for(
		set<dp_index_t>::const_iterator i( erase_list.begin() );
		i != erase_list.end();
		++i
	) {
		if (i->first != d_last) {
			p_correct = 0;
			d_last = i->first;
		}

		domain_list_t::iterator d_pos( domains.begin() );
		assert(domains.size() > i->first-d_correct);
		d_pos += i->first - d_correct;

		path_list_t& paths = *(d_pos->paths);
		path_list_t::iterator p_pos( paths.begin() );
		assert(i->second >= p_correct);
		assert(paths.size() > i->second-p_correct);
		p_pos += i->second - p_correct;

		paths.erase(p_pos);
		++p_correct;
		if (paths.empty() ) {
			delete d_pos->paths;
			domains.erase(d_pos);
			d_correct++;
		}
	}
}

}; // namespace eSoft
#endif
