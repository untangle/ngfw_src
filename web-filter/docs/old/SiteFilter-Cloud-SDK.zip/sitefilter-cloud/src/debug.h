/* Copyright 2008 eSoft, Inc.
 * All Rights Reserved.
 * Licensed under the terms of the eSoft SiteFilter Cache Reference EULA.
 *
 * This code uses the Boost libraries.
 * For more information see: http://www.boost.org/doc/
 */

#ifndef DEBUG_H
#define DEBUG_H
#include <ctime>
#include <iostream>
#include <iomanip>
#include <algorithm>
#include <iterator>
#include "cache.h"
#include "dia.h"

// These functions are for creating debugging output.

namespace eSoft {

inline
std::ostream& operator<<(std::ostream& os, const info_t &x)
{
	os << '{';
	std::copy(
		x.info,
		x.info + info_t::max_categories,
		std::ostream_iterator<uint16_t>(os, ",")
	);
	os << '}';
	return os;
}

inline std::ostream& operator<<(std::ostream& os, const path_entry_t& x)
{
	using namespace std;

	ios::fmtflags save_f( os.flags() );
	int save_w( os.width() );

	std::string tstr(std::ctime(&x.timestamp));
	tstr.erase(tstr.end()-1);

	os << '{';
	os.width(10);
	os.fill('0');
	os.setf( ios::right | ios::hex | ios::showbase );
	os << x.hash;
	os.setf( ios::dec, ios::basefield | ios::showbase );
	os << ',' << x.info;
	os << ',' << tstr;
	os << '}';

	os.width( save_w );
	os.flags( save_f );
	return os;
}

inline std::ostream& operator<<(std::ostream& os, const domain_entry_t& x)
{
	using namespace std;
	os << '{';
	os.width(10);
	os.fill('0');
	os.setf( ios::right | ios::hex | ios::showbase );
	os << x.hash;
	os.setf( ios::dec, ios::basefield | ios::showbase );

	os << "\n\t";
	copy(x.paths->begin(), x.paths->end(), ostream_iterator<path_entry_t>(os, "\n\t"));

	os << "\r}";
	return os;
}

inline std::ostream& operator<<(std::ostream& os, const url_cache& x)
{
	using namespace std;
	const domain_list_t& d = x.get_domains();
	copy(d.begin(), d.end(), ostream_iterator<domain_entry_t>(os, "\n"));
	return os;
}

inline std::ostream& operator<<(std::ostream& os, const dia& x)
{
	using namespace std;
	const dia::outstanding_t& o = x.get_outstanding();
	for(
		dia::outstanding_t::const_iterator i = o.begin();
		i != o.end();
		++i
	) {
		cout << i->first << '\n';
	}
	return os;
}

}; // namespace eSoft
#endif
