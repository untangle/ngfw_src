/* Copyright 2008 eSoft, Inc.
 * All Rights Reserved.
 * Licensed under the terms of the eSoft SiteFilter Cache Reference EULA.
 *
 * This code uses the UDNS library.
 * For more information see: http://www.corpit.ru/mjt/udns.html
 *
 * This code uses the Boost libraries.
 * For more information see: http://www.boost.org/doc/
 */

#ifndef DIA_HPP
#define DIA_HPP

#include <boost/crc.hpp>
#include <iomanip>
#include <iostream>
#include <sstream>
#include <algorithm>
#include <cstring>
#include <cerrno>
#include <time.h>
#include "dia.h"
#include "dlog.h"

namespace eSoft {

using namespace std;

dia::dia(const string& key, const string& serial, const string& host)
: now(time(0)), key(key), serial(serial), host(host),
  request_count(0), failure_count(0)
{
	results.reserve(16);
#ifdef _WIN32
	winsock = false;
	int sock = socket(PF_INET, SOCK_DGRAM, IPPROTO_UDP);
	if (sock < 0) {
		int r = WSAGetLastError();
		if (r == WSANOTINITIALISED) {
			// Winsock is not initialized
			WSADATA ws_data;
			r = WSAStartup(MAKEWORD(2, 2), &ws_data);
		}
		if (r != 0) {
			throw runtime_error("winsock initialization failed");
		}
		winsock = true;
	} else {
		// Winsock is perfectly fine
		closesocket(sock);
	}
#endif
	dns_init(0, 0);
#if 0
	dns_add_serv(0, NULL);
	dns_add_serv(0, "216.38.216.215"); // testrbl1.esoft.com
#endif
	dns_open(0);
}

dia::~dia()
{
	cancel_outstanding();
#ifdef _WIN32
	if (winsock) {
		WSACleanup();
	}
#endif
}

// Calculate the key used to access DIA services.
string dia::auth_calc(const string& url)
{
	string str(url);
	str.append(key);
	str.append(serial);

	boost::crc_ccitt_type result;
	result.process_bytes(str.c_str(), str.length());

	ostringstream os;
	os << setw(4) << setfill('0') << right << hex << result.checksum();
	return os.str();
}

// Escape characters that cannot be used in a DNS query.
string dia::encode_url(const string& url)
{
	string url_s;
	size_t i;
	size_t last_dot = 0;
	char c;
	bool in_domain = true;

	url_s.reserve(url.size()*2);

	for (i = 0; i < url.length(); i++) {
		// Must insert a null escape to divide long spans.
		if (url_s.length() > last_dot+56) {
			url_s.append("_-0.");
			last_dot = url_s.length();
		}

		c = url[i];

		if (c == '.') {
			if( url[i+1] == '/' && in_domain ) {
				// Add nothing
			} else if(
				url_s.length() > 0
				&& url_s.at( url_s.length()-1 ) == '.'
			) {
				url_s.append("_-2e");
			} else {
				url_s.append(1, '.');
				last_dot = url_s.length() - 1;
			}
		} else if ( c == '?' || c == '#' ) {
			// Add nothing and quit.
			break;
		} else if (c == '/') {
			url_s.append("_-.");
			last_dot = url_s.length() - 1;
			in_domain = false;
		} else if (c == ':') {
			url_s.append("_--");
		} else if (c == '%') {
			url_s.append("_-25");
		} else if ( !isalnum(c) && c != '.' && c != '_' && c != '-' ) {
			ostringstream s;
			s << "_-" << setw(2) << hex << static_cast<int>(c);
			url_s.append(s.str());
		} else if (
			c == '_' &&
			url[i+1] == '-'
		) {
			url_s.append("_-_-");
			i += 1;
		} else {
			url_s.append(1, c);
		}
	}
	// If end is a / (_-.) or . then fix it.
	// Keep removing until all are gone.
	while(true) {
		size_t s_len( url_s.length() );
		if( s_len > 2 && url_s.compare(s_len-3, 3, "_-.") == 0 ) {
			url_s.erase( s_len-3 );
		} else if( s_len > 0 && url_s.at( s_len-1 ) == '.' ) {
			url_s.replace( s_len-1, 1, "_-2e" );
		} else {
			break;
		}
	}

	return url_s;
}

// Remove the path from the encoded URL.
// Used for auth_calc.
inline string dia::strip_url(const string& url)
{
	string::size_type p1 = url.find("_-.");
	string::size_type p2 = url.find("_-5c");
	return string(url, 0, min<string::size_type>(p1, p2));
}

// This does all the processing when a DNS query response is received
// by the UDNS library.
void dia::dia_callback(dns_ctx* ctx, void* raw, void* data)
{
	struct dns_parse p;
	struct dns_rr rr;
	const struct dns_rr_txt *rr_txt;
	void *void_rr_txt;
	unsigned char dn[DNS_MAXDN];
	const unsigned char *pkt, *cur, *end;
	int r;

	// data contains a callback_data struct with the original URL
	// and dia object.
	callback_data* cb( static_cast<callback_data*>(data) );
	int rcode;

	r = dns_status(ctx);
	if (!raw)
		goto end_callback;
	if (r < 0)
		goto end_callback;

	pkt = static_cast<const unsigned char *>(raw);
	end = pkt + r;
	cur = dns_payload(pkt);

	dns_getdn(pkt, &cur, end, dn, sizeof(dn));
	dns_initparse(&p, NULL, pkt, cur, end);
	p.dnsp_qcls = (dns_class)0;
	p.dnsp_qtyp = (dns_type)0;

	r = dns_nextrr(&p, &rr);
	if (
		dns_dnequal(dn, rr.dnsrr_dn) &&
		DNS_C_IN == rr.dnsrr_cls &&
		DNS_T_TXT == rr.dnsrr_typ
	) {
		rcode = dns_rcode(pkt);
		switch (rcode) {
		case DNS_R_NOERROR:
			dns_parse_txt(dn, pkt, cur, end, &void_rr_txt);
			rr_txt = static_cast<dns_rr_txt *>(void_rr_txt);

			for(int i=0; i<rr_txt->dnstxt_nrr; ++i) {
				cb->obj->parse_result(cb->url, (const char *)rr_txt->dnstxt_txt[i].txt);
			}
			free(void_rr_txt);
			break;
		}
	}
end_callback:
	DLOG1(cb->outstanding_s);
	cb->obj->outstanding.erase(cb->outstanding_s);
	free(raw);
	delete cb;
}

void dia::parse_result(const std::string& url, const char * txt)
{
	DLOG1(txt);

	// Handle failure responses differently
	static const string fail_txt("FAILURE:");
	static const string refuse_txt("REFUSED:");
	if (
		0 == fail_txt.compare(0, fail_txt.length(), txt, fail_txt.length())
		|| 0 == refuse_txt.compare(0, refuse_txt.length(), txt, refuse_txt.length())
	) {
		result_t result;
		result.code = DNS_R_REFUSED;
		result.url.assign(txt);
		results.push_back(result);
		++failure_count;
		return;
	}

	// Format should be 1_2_3_4_5\tbaseurl\t[dp]
	// Do not skip whitespace: it needs to be read into junk.
	istringstream is(txt);
	char junk;
	is.unsetf(ios::skipws);
	do {
		string base_url;

		result_t result;
		result.code = DNS_R_NOERROR;
		fill(&result.cats[0], &result.cats[max_categories], 0);
		unsigned cat(0);
		do {
			is >> result.cats[cat++];
			is >> junk;
		} while( is && junk == '_' && cat < max_categories);
		is >> base_url;
		is >> junk;
		is >> result.flags;
		is >> junk;

		DLOG2(url, base_url);
		if (base_url.empty()) {
			result.url.assign(url);
			result.authoritative=true;
		} else {
			if( base_url[0] == '.' ) {
				result.authoritative=false;
				result.url.assign(base_url, 1, string::npos);
				// When inserting a non-authoritative record, also insert one for
				// the exact match if the base_url domain matches the end of
				// the original URL domain.
				class url url_1(url);
				class url url_2(base_url);
				if (
					url_1.domain.length() > url_2.domain.length()
					&& 0 == url.compare(
						url_1.domain.length()-url_2.domain.length(),
						url_2.domain.length(),
						url_2.domain
					)
				) {
					result_t result2;
					result2.code = DNS_R_NOERROR;
					std::memcpy(result2.cats, result.cats, sizeof(result.cats[0])*max_categories);
					result2.url = url;
					result2.authoritative=false;
					results.push_back(result2);
				}
			} else {
				result.authoritative = true;
				result.url.assign(base_url);
			}
		}
		results.push_back(result);
	} while( is && junk == '\n' );
}

inline void dia::retrieve(unsigned timeout)
{
	wait(0, 0, timeout);
}

#ifdef _WIN32
inline int dia::poll(struct pollfd *pfd, unsigned nfds, int timeout)
{
	unsigned i;

	// Convert pollfd into select
	fd_set rs, ws, es;

	FD_ZERO(&rs);
	FD_ZERO(&ws);
	FD_ZERO(&es);
	for(i=0; i<nfds; i++) {
		if( pfd[i].events & POLLIN )
			FD_SET(pfd[i].fd, &rs);
		if( pfd[i].events & POLLOUT )
			FD_SET(pfd[i].fd, &ws );
		if( pfd[i].events & POLLERR )
			FD_SET(pfd[i].fd, &es);
	}
	// Convert timeout from milliseconds to timeval in seconds, microseconds
	struct timeval tmout;
	tmout.tv_sec = timeout / 1000;
	tmout.tv_usec = (timeout % 1000) * 1000;

	int r = select(nfds, &rs, &ws, &es, &tmout);
	if (r == SOCKET_ERROR)
		throw runtime_error("poll error");
	return r;
}
#else
inline int dia::poll(struct pollfd *pfd, unsigned nfds, int timeout)
{
	int r = ::poll(pfd, nfds, timeout);
	if (r < 0 && errno != EINTR)
		throw runtime_error("poll error");
	return r;
}
#endif

// Process DNS events until timeout or until a poll event.
// Returns:
//   Number of poll events if there was an event.
//   0 if it was a time out.
//   -1 if there are no DNS queries to wait for.
// Note on -1: a runtime_error exception is thrown for poll errors
// instead of a -1 return.
int dia::wait(pollfd *ufds, unsigned nfds, unsigned timeout)
{
	int n;
	int poll_r = 0;
	now = time(0);

	if (timeout) {
		time_t end(now+timeout);
		pollfd *pfds = new pollfd[nfds+1];
		try {
			int sock = dns_sock(0);
			pfds[0].fd = sock;
			pfds[0].events = POLLIN;
			if (nfds)
				std::memcpy(&pfds[1], &ufds[0], sizeof(*pfds)*nfds);

			n = dns_timeouts(0, -1, now);
			while(n >= 0 && now < end) {
				poll_r = poll(pfds, nfds+1, min<int>(n, end-now) * 1000);

				now = time(0);
				dns_ioevent(0, now);
				n = dns_timeouts(0, -1, now);

				// break out early if we got something.
				if (poll_r > 0) {
					break;
				}
			}

			if (nfds)
				std::memcpy(&ufds[0], &pfds[1], sizeof(*pfds)*nfds);
		} catch (...) {
			delete[] pfds;
			throw;
		}
		delete[] pfds;
	} else {
		n = dns_timeouts(0, -1, now);
		dns_ioevent(0, now);
	}

	return (n<0) ? n : poll_r;
}


void dia::cancel_outstanding()
{
	for(
		outstanding_t::const_iterator i = outstanding.begin();
		i != outstanding.end();
		++i
	) {
		DLOG1(i->first);
		dns_cancel(0, i->second);
	}
	outstanding.clear();
}

void dia::build_query_dn(const int *cats, const string &url, dnsc_t dn[DNS_MAXDN])
{
	static const string dot(".");
	string e_url( encode_url( url::decode(url) ) );
	bool suggest(cats && cats[0]);
	string query;

	if (suggest) {
		ostringstream cats_s;
		for(size_t i=0; i<max_categories; ++i) {
			if (cats[i] <= 0)
				continue;
			if (i>0) cats_s << '_';
			cats_s << cats[i];
		}
		query = cats_s.str();
	} else {
		query = "0";
	}
	query
		.append("_a")
		.append(dot);

	// If the length of e_url + serial + authkey + host + all the dots exceeds 255
	// then trim it until it will fit.
	// Trim by removing path components, then domain components.
	int attempts = 256/4;
	while(
		--attempts > 0
		&& (
			e_url.at( e_url.length()-1 ) == '.'
			|| query.length() + e_url.length() + serial.length() + 4 + host.length() + 5 >= 254
		)
	) {
		string::size_type path_pos = e_url.rfind("_-.", 256);
		if( path_pos != string::npos ) {
			e_url.erase(path_pos);
		} else {
			string::size_type domain_pos = e_url.find('.');
			if( domain_pos != string::npos ) {
				e_url.erase(0, domain_pos+1);
			}
		}
	}

	string authkey( auth_calc(strip_url(e_url) ) );
	DLOG1(strip_url(e_url));
	query
		.append(e_url)
		.append(dot)
		.append(authkey);
	if( !serial.empty() ) {
		query
			.append(dot)
			.append(serial);
	}
	query
		.append(dot)
		.append(host);

	DLOG1(query);

	if( dns_ptodn(query.c_str(), query.length(), dn, sizeof(*dn)*DNS_MAXDN, NULL) < 0 ) {
		throw submit_error(query);
	}
}

void dia::submit(const std::string &url)
{
	string outstanding_s(url, 0, url.rfind('/'));
	DLOG1(outstanding_s);
	outstanding_t::iterator oi;
	if( outstanding.find(outstanding_s) == outstanding.end() ) {
		oi =
			outstanding.insert(outstanding.begin(), make_pair(outstanding_s,(dns_query*)0));
		try {
			dnsc_t dn[DNS_MAXDN];
			build_query_dn(0, url, dn);

			// This callback_data object and the outstanding entry will be
			// cleaned up at the end of dia_callback.
			callback_data *data = new callback_data;
			data->outstanding_s = outstanding_s;
			data->url = url;
			data->obj = this;
			oi->second = dns_submit_dn(
				0, dn, DNS_C_IN, DNS_T_TXT, DNS_NOSRCH, 0,
				&dia_callback, static_cast<void*>(data)
			);
			if( !oi->second )
				throw submit_error(url);
			++request_count;
		} catch (...) {
			outstanding.erase(oi);
			throw;
		}
	} else {
		DLOG("already outstanding");
	}

	dns_timeouts(0, 0, 0);
}

void dia::report(const int cats[max_categories], const std::string &url)
{
	dnsc_t dn[DNS_MAXDN];
	build_query_dn(cats, url, dn);
	dns_submit_dn(
		0, dn, DNS_C_IN, DNS_T_TXT, DNS_NOSRCH, 0,
		NULL, NULL
	);
	++request_count;
	dns_timeouts(0, 0, 0);
}

}; // namespace eSoft
#endif
