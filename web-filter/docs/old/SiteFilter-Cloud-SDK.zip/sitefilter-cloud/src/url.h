/* Copyright 2008 eSoft, Inc.
 * All Rights Reserved.
 * Licensed under the terms of the eSoft SiteFilter Cache Reference EULA.
 */

#ifndef URL_H
#define URL_H

#include <string>
#include <sstream>
#include <iomanip>
#include <algorithm>
#include <cctype>

#undef min
#undef max

namespace eSoft {

// A URL class useful for dividing a string into URL parts.
class url {
public:
	std::string protocol;
	std::string auth;
	std::string domain;
	unsigned port;
	std::string path;
	std::string query;

	url(const std::string &s)
	{ construct(s); }
	url(const char *s)
	{ construct(s); }

	static std::string decode(const std::string &s);
	static std::string encode(const std::string &s);
	static std::string lower_case(const std::string &s);
	static std::string back_to_slash(const std::string &s);
private:
	void construct(const std::string &s);
};

inline
void url::construct(const std::string &s)
{
	using namespace std;
	string::size_type start(0);
	string::size_type pos;
	string::size_type path_start;
	string::size_type slash_pos;
	string::size_type bslash_pos;

	pos = s.find("://", start);
	slash_pos = s.find('/', start);
	bslash_pos = s.find('\\', start);
	if (pos != string::npos && pos < slash_pos && pos < bslash_pos) {
		protocol = lower_case( string(s, start, pos) );
		start = pos + 3;
		if (protocol == "http")
			port = 80;
		else if (protocol == "https")
			port = 443;
		else if (protocol == "ftp")
			port = 21;
		else
			port = 0;
	} else {
		protocol = "http";
		port = 80;
	}

	slash_pos = s.find('/', start);
	bslash_pos = s.find('\\', start);
	path_start = std::min(slash_pos, bslash_pos);

	pos = s.find('@', start);
	if (pos != string::npos && pos < path_start) {
		auth.assign(s, start, pos-start);
		start = pos + 1;
	}

	pos = s.find(':', start);
	if (pos != string::npos && pos < path_start) {
		istringstream is( string(s, pos+1, path_start-pos) );
		is >> port;
		domain = decode( lower_case( string(s, start, pos-start) ) );
	} else {
		domain = decode( lower_case( string(s, start, path_start-start) ) );
	}

	if( path_start == string::npos ) {
		path.assign(1, '/');
		start = string::npos;
		pos = string::npos;
	} else {
		start = path_start;
		while( s[start+1] == '/' || s[start+1] == '\\' )
			start++;
		pos = s.find('?', start);
		if (pos == string::npos)
			pos = s.find('#', start);
		if (pos != string::npos) {
			path = decode( string(s, start, pos-start) );
			// Do not decode the query here because each key-value needs to be decoded.
			query = string(s, pos, string::npos);
		} else {
			path = decode( string(s, start, string::npos) );
		}
	}
	while( domain.at( domain.length()-1 ) == '.' )
		domain.erase( domain.length()-1 );
}

inline
std::string url::decode(const std::string &s)
{
	using namespace std;
	if( s.length() < 3 )
		return s;

	char ts[4] = {0, 0, 0, 0};
	char *tsp;
	int c;
	string result(s.length(), '\0');
	string::const_iterator src( s.begin() );
	string::const_iterator src_end( s.end() );
	string::iterator dst( result.begin() );
	while(src < src_end-2 ) {
		c = *src;
		if( c == '%' ) {
			ts[0] = *(src+1);
			ts[1] = *(src+2);
			c = strtol(ts, &tsp, 16);
			if( tsp == ts+2 ) {
				src += 2;
			} else {
				c = '%';
			}
		}
		*dst = c;
		++dst; ++src;
	}
	while(src != src_end ) {
		*dst = *src;
		++dst; ++src;
	}
	result.erase(dst, result.end());
	return result;
}

inline
std::string url::encode(const std::string &s)
{
	using namespace std;

	static const string unreserved("-_.!~*'()");
	ostringstream os;
	os.str().reserve(s.length());
	for(
		string::const_iterator c(s.begin());
		c != s.end();
		++c
	) {
		if( isalnum(*c) || unreserved.find(*c) != string::npos ) {
			os << *c;
		} else {
			os << '%';
			os << hex << setw(2) << setfill('0') << static_cast<int>(*c);
		}
	}
	return os.str();
}

inline
std::string url::lower_case(const std::string &s)
{
	using namespace std;
	string result(s.length(), '\0');
	string::const_iterator src( s.begin() );
	string::iterator dst( result.begin() );
	while(src != s.end() ) {
		*dst = tolower(*src);
		++dst; ++src;
	}
	return result;
}

inline
std::string url::back_to_slash(const std::string &s)
{
	using namespace std;
	string result(s.length(), '\0');
	replace_copy(s.begin(), s.end(), result.begin(), '\\', '/');
	return result;
}

}; // namespace eSoft
#endif
