/* Copyright 2008 eSoft, Inc.
 * All Rights Reserved.
 * Licensed under the terms of the eSoft SiteFilter Cache Reference EULA.
 *
 * This code uses the UDNS library.
 * For more information see: http://www.corpit.ru/mjt/udns.html
 */

#ifndef DIA_H
#define DIA_H

#ifdef _WIN32
# include <winsock2.h>
#else
# include <sys/poll.h>
# define HAVE_POLL
#endif

#include <vector>
#include <map>
#include <string>
#include <stdexcept>
#include "udns.h"
#include "url.h"

namespace eSoft {

// The dia class implements the DNS lookup of URL classifications from
// the eSoft DIA services.
class dia {
public:
	static const unsigned max_categories = 5;
	struct result_t {
		std::string url;
		std::string flags;
		int code;
		int cats[max_categories];
		bool authoritative;
	};
	typedef std::vector<result_t> result_list_t;
	typedef std::map<std::string, dns_query*> outstanding_t;

	dia(const std::string& key, const std::string& serial, const std::string& host);
	~dia();

	void retrieve(unsigned timeout);
	int wait(pollfd *ufds, unsigned nfds, unsigned sec);
	void submit(const std::string &url);
	void report(const int cats[max_categories], const std::string &url);

	void cancel_outstanding();
	const outstanding_t& get_outstanding() const
	{ return outstanding; }

	const result_list_t& get_results() const
	{ return results; }
	void clear_results()
	{ results.clear(); }

	unsigned get_request_count() const
	{ return request_count; }

	unsigned get_failure_count() const
	{ return failure_count; }

	static int poll(struct pollfd *pfd, unsigned nfds, int timeout);

protected:
	struct callback_data {
		std::string outstanding_s;
		std::string url;
		dia* obj;
	};

	time_t now;
	const std::string key;
	const std::string serial;
	const std::string host;
	unsigned request_count;
	unsigned failure_count;
	outstanding_t outstanding;
	result_list_t results;
#ifdef _WIN32
	bool winsock;
#endif

	std::string auth_calc(const std::string& url);
	void build_query_dn(const int *cats, const std::string &url, dnsc_t dn[DNS_MAXDN]);

	static std::string encode_url(const std::string& url);
	static std::string strip_url(const std::string& url);
private:

	dia(const dia&);
	dia& operator=(const dia&);

	static void dia_callback(dns_ctx* ctx, void* raw, void* data);
	void parse_result(const std::string& url, const char * result);
};

class submit_error : public std::runtime_error {
public:
	submit_error(const std::string &s)
	: std::runtime_error(s)
	{}
};

};

#include "dia.hpp"
#endif
