/* Copyright 2008 eSoft, Inc.
 * All Rights Reserved.
 * Licensed under the terms of the eSoft SiteFilter Cache Reference EULA.
 *
 * This code uses the Boost libraries.
 * For more information see: http://www.boost.org/doc/
 */
#ifndef ALLOCATOR_H
#define ALLOCATOR_H
#include <stdexcept>
#include <cassert>
#include <boost/pool/pool_alloc.hpp>
#include <boost/pool/detail/singleton.hpp>
#include "dlog.h"

namespace eSoft {

// The memory_limiter class tracks memory usage for tracking_pool_allocator.
// When the memory limit is reached, a bad_alloc exception is thrown.
// This uses a Boost singleton to hold the memory_limiter data.
class memory_limiter {
	struct data {
		size_t used;
		size_t limit;
		data() : used(0), limit(1*1024*1024) {}
	};
	typedef boost::details::pool::singleton_default<data> singleton;
public:
	static void use(size_t n)
	{
		data & d = singleton::instance();
		unsigned t_used = d.used + n;
		if (t_used > d.limit) {
			throw std::bad_alloc();
		}
		d.used = t_used;
	}
	static void free(size_t n)
	{
		data & d = singleton::instance();
		if (d.used < n)
			throw std::runtime_error("freeing more memory than allocated");
		d.used -= n;
	}
	static size_t used()
	{
		data & d = singleton::instance();
		return d.used;
	}
	static size_t limit(size_t x=0)
	{
		data & d = singleton::instance();
		size_t tmp(d.limit);
		if(x)
			d.limit = x;
		return tmp;
	}
};

// tracking_pool_allocator is used to allocate space for cache entries and
// to track that space so that it may be kept to a limited size.
// The size limit is managed by the memory_limiter class and is defined as
// a number of bytes.
// The number of cache records stored will depend on the size of each record.
template<typename X>
class tracking_pool_allocator
: public boost::fast_pool_allocator<
	X,
	boost::default_user_allocator_new_delete,
	boost::details::pool::null_mutex,
	512
> {
public:
	typedef boost::fast_pool_allocator<
		X,
		boost::default_user_allocator_new_delete,
		boost::details::pool::null_mutex,
		512
	> _Parent;
	static typename _Parent::pointer allocate(typename _Parent::size_type n)
	{
		DLOG2(n, sizeof(X));
		memory_limiter::use(n * sizeof(X));
		return _Parent::allocate(n);
	}
	static typename _Parent::pointer allocate(
		typename _Parent::size_type n,
		typename _Parent::pointer p
	) {
		DLOG2(n, sizeof(X));
		memory_limiter::use(n * sizeof(X));
		return _Parent::allocate(n, p);
	}
	static void deallocate(typename _Parent::pointer ptr, typename _Parent::size_type n)
	{
		DLOG2(n, sizeof(X));
		memory_limiter::free(n * sizeof(X));
		return _Parent::deallocate(ptr, n);
	}
public:
	template <typename U>
	struct rebind
	{
		typedef tracking_pool_allocator<U> other;
	};
	tracking_pool_allocator()
	{ }
	template <typename U>
	tracking_pool_allocator(const tracking_pool_allocator<U> &)
	{ }
};

// The fast_pod_allocator is used for efficient memory management of POD
// types.  A POD type is Plain Old Data: a class or structure that does
// not use special C++ features.
template<class T>
class fast_pod_allocator {
public:
	static void* operator new(size_t size)
	{
		assert(size == sizeof(T));
		return tracking_pool_allocator<T>::allocate(1);
	}
	static void* operator new(size_t size, void *p)
	{ return ::operator new(size, p); }
	static void operator delete(void* deletable, size_t size)
	{
		assert(size == sizeof(T));
		if (deletable)
			tracking_pool_allocator<T>::deallocate( static_cast<T*>(deletable), 1);
	}
};

}; // namespace eSoft
#endif
