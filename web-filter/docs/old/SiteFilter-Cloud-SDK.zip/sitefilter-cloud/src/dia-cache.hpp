/* Copyright 2008 eSoft, Inc.
 * All Rights Reserved.
 * Licensed under the terms of the eSoft SiteFilter Cache Reference EULA.
 *
 * This code uses the UDNS library.
 * For more information see: http://www.corpit.ru/mjt/udns.html
 *
 * This code uses the Boost libraries.
 * For more information see: http://www.boost.org/doc/
 */

#ifndef DIA_CACHE_HPP
#define DIA_CACHE_HPP

#include "dia-cache.h"

namespace eSoft {

using namespace std;

void cached_dia::cache_results(url_cache &cache)
{
	const result_list_t &results = get_results();
	// Do all good responses first.
	for(
		result_list_t::const_iterator i( results.begin() );
		i != results.end();
		++i
	) {
		if (i->code == DNS_R_NOERROR) {
			info_t info;
			for_each(&i->cats[0], &i->cats[dia::max_categories], category_encoder(info));
			if (i->authoritative)
				mark_authoritative(info);
			try {
				cache.insert(i->url, info, now);
			} catch(const bad_alloc&) {
				cache.clean_oldest_n(1000);
				cache.insert(i->url, info, now);
			}
		}
	}
	// Scan for errors.
	for(
		result_list_t::const_iterator i( results.begin() );
		i != results.end();
		++i
	) {
		if (i->code == DNS_R_REFUSED) {
			submit_error e(i->url);
			clear_results();
			throw e;
		}
	}
	clear_results();
}

info_t cached_dia_async::lookup( const string &url_s )
{
	class url url( url_s );
	while( wait(0) > 0)
		/* continue looping while receiving data */;
	cache_results(*this);
	info_t result( url_cache::lookup(url) );
	if (!result || !is_authoritative(result) ) {
		string domain_path( url.domain + url.path );
		dia::submit(domain_path);
	}

	return result;
}

info_t cached_dia_sync::lookup( const string &url_s ) {
	class url url( url_s );
	info_t result( url_cache::lookup(url) );
	if (!result || !is_authoritative(result) ) {
		string domain_path( url.domain + url.path );
		dia::submit(domain_path);
	}
	while( wait(wait_secs) > 0)
		/* continue looping while receiving data and wait up to 5 seconds */;
	cache_results(*this);
	dia::cancel_outstanding();
	result = url_cache::lookup(url);

	return result;
}

}; // namespace eSoft
#endif
