/* Copyright 2008 eSoft, Inc.
 * All Rights Reserved.
 * Licensed under the terms of the eSoft SiteFilter Partner EULA.
 */

#define BOOST_AUTO_TEST_MAIN
#include <boost/test/auto_unit_test.hpp>
#include <boost/test/included/unit_test_framework.hpp>

#include "cache.h"
#include "dia.h"
#include "dia-cache.h"
#include "debug.h"
#include <algorithm>
#include <string>
#include <sstream>
#include <iostream>

using namespace std;
using namespace eSoft;

#error Define key, serial, host.
string key("");
string serial("");
string host("");

struct test_and_result {
	const char *test;
	const char *result;
};

BOOST_AUTO_TEST_CASE( url_split )
{
	url a("esoft.com");
	BOOST_CHECK(a.protocol == "http");
	BOOST_CHECK(a.auth.empty());
	BOOST_CHECK(a.domain == "esoft.com");
	BOOST_CHECK(a.port == 80);
	BOOST_CHECK(a.path == "/");
	BOOST_CHECK(a.query.empty());

	url b("http://esoft.com");
	BOOST_CHECK(b.protocol == "http");
	BOOST_CHECK(b.domain == "esoft.com");
	BOOST_CHECK(b.port == 80);
	BOOST_CHECK(b.path == "/");

	url c("https://esoft.com");
	BOOST_CHECK(c.protocol == "https");
	BOOST_CHECK(c.port == 443);

	url d("esoft.com:81");
	BOOST_CHECK(d.protocol == "http");
	BOOST_CHECK(d.domain == "esoft.com");
	BOOST_CHECK(d.port == 81);

	url e("http://esoft.com:81");
	BOOST_CHECK(e.protocol == "http");
	BOOST_CHECK(e.domain == "esoft.com");
	BOOST_CHECK(e.port == 81);

	url f("https://esoft.com:8001");
	BOOST_CHECK(f.protocol == "https");
	BOOST_CHECK(f.domain == "esoft.com");
	BOOST_CHECK(f.port == 8001);

	url g("https://admin:testpass@esoft.com");
	BOOST_CHECK(g.protocol == "https");
	BOOST_CHECK(g.auth == "admin:testpass");
	BOOST_CHECK(g.domain == "esoft.com");

	url h("esoft.com/path");
	BOOST_CHECK(h.protocol == "http");
	BOOST_CHECK(h.domain == "esoft.com");
	BOOST_CHECK(h.port == 80);
	BOOST_CHECK(h.path == "/path");
	BOOST_CHECK(h.query.empty());

	url i("esoft.com:81/path");
	BOOST_CHECK(i.protocol == "http");
	BOOST_CHECK(i.domain == "esoft.com");
	BOOST_CHECK(i.port == 81);
	BOOST_CHECK(i.path == "/path");
	BOOST_CHECK(i.query.empty());

	url j("esoft.com/path/morepath:blah@/http://blah.com/path");
	BOOST_CHECK(j.protocol == "http");
	BOOST_CHECK(j.domain == "esoft.com");
	BOOST_CHECK(j.port == 80);
	BOOST_CHECK(j.path == "/path/morepath:blah@/http://blah.com/path");
	BOOST_CHECK(j.query.empty());

	url k("esoft.com/path/morepath/?submit");
	BOOST_CHECK(k.protocol == "http");
	BOOST_CHECK(k.domain == "esoft.com");
	BOOST_CHECK(k.port == 80);
	BOOST_CHECK(k.path == "/path/morepath/");
	BOOST_CHECK(k.query == "?submit");

	url l("http://www.gamedev.net/community/forums/topic.asp?topic_id=353479&PageSize=25&WhichPage=1");
	BOOST_CHECK(l.protocol == "http");
	BOOST_CHECK(l.domain == "www.gamedev.net");
	BOOST_CHECK(l.port == 80);
	BOOST_CHECK(l.path == "/community/forums/topic.asp");
	BOOST_CHECK(l.query == "?topic_id=353479&PageSize=25&WhichPage=1");
}

BOOST_AUTO_TEST_CASE( test_lower_case )
{
	string t1("This Is a TEST!");
	string t1r = url::lower_case(t1);
	BOOST_CHECK(t1r == "this is a test!");
	BOOST_CHECK(t1r.length() == t1.length());

	BOOST_CHECK(url::lower_case("testing ONE Two THRee") == "testing one two three");
}

#if 1
class test_dia : public dia
{
public:
	test_dia(const std::string& key, const std::string& serial, const std::string& host)
	: dia(key, serial, host)
	{}
	static std::string encode_url(const std::string& url)
	{ return dia::encode_url( url::decode(url) ); }
};

BOOST_AUTO_TEST_CASE( test_encode_url )
{
	struct test_and_result tests[] = {
		{
			"ad.doubleclick.net/adj/cm.peo/homepage;ch=homepage;ptype=channel;sz=240x52;path=people;dcove=d;cmpos=globalheader;cmtyp=tout;dcopt=ist;pg",
			"ad.doubleclick.net_-.adj_-.cm.peo_-.homepage_-3bch_-3dhomepage_-3bptype_-3dchannel_-3bsz_-3d_-0.240x52_-3bpath_-3dpeople_-3bdcove_-3dd_-3bcmpos_-3dglobal_-0.header_-3bcmtyp_-3dtout_-3bdcopt_-3dist_-3bpg"
		},
		{
			"www.example.com/::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::",
			"www.example.com_-._--_--_--_--_--_--_--_--_--_--_--_--_--_--_--_--_--_--_--_-0._--_--_--_--_--_--_--_--_--_--_--_--_--_--_--_--_--_--_--_-0._--_--_--_--_--_--_--_--_--_--_--_--_--_--_--_--_--_--_--_-0._--_--_--"
		},
		{
			"www.example.com/%_-%%",
			"www.example.com_-._-25_-_-_-25_-25"
		},
		{
			"www.example.com/............................................................",
			"www.example.com_-._-2e._-2e._-2e._-2e._-2e._-2e._-2e._-2e._-2e._-2e._-2e._-2e._-2e._-2e._-2e._-2e._-2e._-2e._-2e._-2e._-2e._-2e._-2e._-2e._-2e._-2e._-2e._-2e._-2e._-2e_-2e"
		},
		{
			"www.example.com/./../.../......................................................",
			"www.example.com_-._-2e_-._-2e._-._-2e._-2e_-._-2e._-2e._-2e._-2e._-2e._-2e._-2e._-2e._-2e._-2e._-2e._-2e._-2e._-2e._-2e._-2e._-2e._-2e._-2e._-2e._-2e._-2e._-2e._-2e._-2e._-2e._-2e_-2e"
		},
		{
			"www.example.com/'too%20big'",
			"www.example.com_-._-27too_-20big_-27"
		},
		{
			"www.example.com/'too%20",
			"www.example.com_-._-27too_-20"
		},
		{
			"www.example.com/'too%20/",
			"www.example.com_-._-27too_-20"
		},
		{
			"www.example.com/index.html?p=7&q=8",
			"www.example.com_-.index.html"
		},
		{
			"www.example.com/?p=7&q=8",
			"www.example.com"
		},
		{
			"www.example.com/index.htm#mark",
			"www.example.com_-.index.htm"
		},
		{
			"www.example.com/#mark",
			"www.example.com"
		},
		{
			"www.example.com/a;b:c!d@e$f%g^h*i(j)k+l[m]n\\o`p",
			"www.example.com_-.a_-3bb_--c_-21d_-40e_-24f_-25g_-5eh_-2ai_-28j_-29k_-2bl_-5b_-0.m_-5dn_-5co_-60p"
		},
		{
			"www.example.com/_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-",
			"www.example.com_-._-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-0._-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-0._-_-"
		},
		{
			"www.example.com\\documents",
			"www.example.com_-5cdocuments"
		},
		{
			"www.example.com%5cdocuments",
			"www.example.com_-5cdocuments"
		},
		{
			"www.example.com%2fdocuments",
			"www.example.com_-.documents"
		},
		{
			"10.0.11.10/secars/secars.dll?h=A15DD3CD92642F5454E3F9DD279F87B29BF86E8A36406BB24322831C1CB32CC6351BC5260D159FA1C898A84A74D96FFAD5CFE1A426BFBA87EE45685B529277E0BF2620BE5E3399E24938A78B882EA9126952DE98CA0AB0043DD90AFC7DDA48801269F90492F4CFCAD3ED1E9038BB1404E9A1C56D2314AE85F6225E5403BAF868A741BE7DB77E88E63A28469F5ADEEBE23D80E595A256C208F09F97CCF7BDBD9CD00641A65B5CC8D764D9658CB2D87D4919151226732AF58B01184A443B3F90F12B6F97633AB2282FAB899739C8B1D9115107DE1374CCD0A54E5A70A552AC79B603C8D3C49C6577737DB128FA2DEDE5334CFA96D1E4F6CA957F17883D9EC6893EC13A6BC39813D8474FC4F07CCB300CE98548A0F6501276DB39321D3B060A275BC03D4DDCF77106C649B6A4EBD7BA82F9B8B7BC809FC207A07E9DAB09A60694770986CDA664853B96316BF96C93E7E7A0EBE7DCBD6768FEE33A737F1D5D6A7608586F940FCC30C22023CFD25034E4FAC82431E5088D2A9950F7369667258852A34A0A780B3F54D4C85EE7548593DA518187C65CFB94E51892373F328DE8C267F947FE97D03D560DFB002740C425BF6290",
			"10.0.11.10_-.secars_-.secars.dll"
		},
		{
			"najeho.co.il:80/gambling_20081222_06.htm",
			"najeho.co.il_--80_-.gambling_20081222_06.htm"
		},
		{
			"example.com//",
			"example.com"
		},
	};
	const size_t tests_len = sizeof(tests)/sizeof(tests[0]);
	string result;
	unsigned int i;

	for( i=0; i<tests_len; ++i ) {
		result = test_dia::encode_url( tests[i].test );
		if( result != tests[i].result ) {
			clog
				<< "test:      "<<tests[i].test<<'\n'
				<< "result:    "<<result<<'\n'
				<< "should be: "<<tests[i].result<<endl;
		}
		BOOST_CHECK( result == tests[i].result );
	}
}
#endif

#if 1
BOOST_AUTO_TEST_CASE( dia_lookup_async )
{
	cout << __func__ << endl;
	cached_dia_async dia(key, serial, host);
	vector<string> urls(30);
	vector<string>::iterator i;
	int j=0;
	info_t result;

	for( i = urls.begin(); i != urls.end(); ++i, ++j ) {
		ostringstream os;
		if (j%2==0)
			os << "www.";
		os << "microsoft.com/images/" << j << ".GIF";
		*i = os.str();
	}

	// Make all requests
	for( i = urls.begin(); i != urls.end(); ++i ) {
		result = dia.lookup(*i);
//cout << *static_cast<class dia *>(&dia);
//cout << dia.get_request_count() << ',' << dia.get_domains().size() << endl;
	}

//cout << *static_cast<class dia *>(&dia);
//cout << *static_cast<class url_cache *>(&dia);

	unsigned last_count = dia.get_request_count();
	// Must be at least 2 requests because www.microsoft.com and microsoft.com
	// should each get one.
	BOOST_CHECK( last_count >= 2 && last_count < urls.size() );

	while( dia.wait(5) > 0 )
		/* do nothing */;

	// Check all responses
	for( i = urls.begin(); i != urls.end(); ++i ) {
		result = dia.lookup(*i);
		unsigned cat_1 = category_decoder(result)();
		if( cat_1 != 13 )
			cout << "lookup " << *i << " result=" << result << endl;
		BOOST_CHECK( is_authoritative(result) );
		BOOST_CHECK( cat_1 == 13);
	}

	// Verify there were no more requests
	BOOST_CHECK( dia.get_request_count() == last_count );

	// Check secondary responses
	// Verify that these DO make more requests, they are marked with the dot.
	// Note: Must be using url-test.esoft.com for this to work.
	result = dia.lookup("www.ESOFT.com");
	BOOST_CHECK( !is_authoritative(result) );
	BOOST_CHECK( category_decoder(result)() == 13);
	BOOST_CHECK( dia.get_request_count() == last_count+1 );

	result = dia.lookup("www.zlynx.org");
	BOOST_CHECK( !is_authoritative(result) );
	BOOST_CHECK( category_decoder(result)() == 25);
	BOOST_CHECK( dia.get_request_count() == last_count+2 );

	while( dia.wait(5) > 0 )
		/* do nothing */;

	// Check exact match responses
	result = dia.lookup("www.zlynx.ORG");
	BOOST_CHECK( is_authoritative(result) );
	BOOST_CHECK( category_decoder(result)() == 25);
	BOOST_CHECK( dia.get_request_count() == last_count+2 );
}
#endif

BOOST_AUTO_TEST_CASE( dia_lookup_weird )
{
	cout << __func__ << endl;
	cached_dia_sync dia(key, serial, host, 5);
	vector<string> urls;
	vector<string>::iterator url_i;
	vector<unsigned> results;
	vector<unsigned>::iterator result_i;
	info_t result;

	urls.reserve(30);
	results.reserve(30);
	urls.push_back( "example.com\\documents" );
	results.push_back(54);
	urls.push_back( "example.org/.\\../...\\documents" );
	results.push_back(13);
	urls.push_back( "example.org/." );
	results.push_back(13);
	urls.push_back( "example.org./" );
	results.push_back(13);
	urls.push_back( "example.org/.pub.//" );
	results.push_back(13);
	urls.push_back( "example.org/.pub.//" );
	results.push_back(13);
	urls.push_back( "example.net%2fdocuments%5cpublic" );
	results.push_back(13);
	urls.push_back( "www.site.com/'too%20big'" );
	results.push_back(30);
	urls.push_back( "www.joe.com//" );
	results.push_back(52);
	urls.push_back( "www.zoe.com:81///path/to/somewhere" );
	results.push_back(50);
	// Make all requests
	for(
		url_i = urls.begin(), result_i = results.begin();
		url_i != urls.end() && result_i != results.end();
		++url_i, ++result_i
	) {
		cout << "about to lookup '" << *url_i << "'\n";
		result = dia.lookup(*url_i);
		BOOST_CHECK( is_authoritative(result) );
		BOOST_CHECK( category_decoder(result)() == *result_i );
	}
}

BOOST_AUTO_TEST_CASE( dia_lookup_submit_txt )
{
	cout << __func__ << endl;
	cached_dia_sync dia(key, serial, host, 5);

	info_t result;
	ifstream in("submit-test.txt");
	string url;
	while( getline(in, url) ) {
		result = dia.lookup(url);
		if( !result ) {
			cout << "no result: '" << url << "'\n";
		}
		BOOST_CHECK( !!result );
	}
}

BOOST_AUTO_TEST_CASE( dia_lookup_sync )
{
	cout << __func__ << endl;
	cached_dia_sync dia(key, serial, host, 5);
	vector<string> urls(30);
	vector<string>::iterator i;
	int j=0;
	info_t result;

	for( i = urls.begin(); i != urls.end(); ++i, ++j ) {
		ostringstream os;
		if (j%2==0)
			os << "WWW.";
		os << "microsoft.com/images/" << j << ".gif";
		*i = os.str();
	}

	// Make all requests
	for( i = urls.begin(); i != urls.end(); ++i ) {
		result = dia.lookup(*i);
		BOOST_CHECK( is_authoritative(result) );
		BOOST_CHECK( category_decoder(result)() == 13);
	}

	unsigned last_count = dia.get_request_count();
	BOOST_CHECK( last_count >= 1 && last_count < urls.size() );

	// Check secondary responses
	result = dia.lookup("www.esoft.com");
	BOOST_CHECK( is_authoritative(result) );
	BOOST_CHECK( category_decoder(result)() == 13);
	BOOST_CHECK( dia.get_request_count() == last_count+1 );

	result = dia.lookup("WWW.zlynx.org");
	BOOST_CHECK( is_authoritative(result) );
	BOOST_CHECK( category_decoder(result)() == 25);
	BOOST_CHECK( dia.get_request_count() == last_count+2 );

	// Check exact match responses
	result = dia.lookup("www.zlynx.org");
	BOOST_CHECK( is_authoritative(result) );
	BOOST_CHECK( category_decoder(result)() == 25);
	BOOST_CHECK( dia.get_request_count() == last_count+2 );
}

BOOST_AUTO_TEST_CASE( url_cache_overwrite )
{
	cout << __func__ << endl;
	url_cache cache;
	info_t ival;
	(category_encoder(ival))(123);
	cache.insert("www.esoft.com", ival);
	BOOST_CHECK( cache.get_domains().size() == 1 );

	info_t result;
	result = cache.lookup("www.esoft.com");
	BOOST_CHECK( category_decoder(result)() == 123 );
	//cout << cache << '\n';

	(category_encoder(ival))(234);
	cache.insert("www.esoft.com", ival);
	BOOST_CHECK( cache.get_domains().size() == 1 );
	result = cache.lookup("www.esoft.com");
	BOOST_CHECK( category_decoder(result)() == 234 );
	//cout << cache << '\n';
}

BOOST_AUTO_TEST_CASE( url_cache_many_paths )
{
	cout << __func__ << endl;
	url_cache cache;
	info_t ival;
	(category_encoder(ival))(1);
	cache.insert("www.esoft.com", ival);
	(category_encoder(ival))(2);
	cache.insert("www.esoft.com/a", ival);
	(category_encoder(ival))(3);
	cache.insert("www.esoft.com/beta", ival);
	(category_encoder(ival))(4);
	cache.insert("www.esoft.com/gamma/delta", ival);

	BOOST_CHECK( cache.get_domains().size() == 1 );
	BOOST_CHECK( cache.get_domains().at(0).paths->size() == 4 );

	info_t result;
	result = cache.lookup("www.esoft.com");
	BOOST_CHECK( category_decoder(result)() == 1 );
	result = cache.lookup("www.esoft.com/a");
	BOOST_CHECK( category_decoder(result)() == 2 );
	result = cache.lookup("www.esoft.com/beta");
	BOOST_CHECK( category_decoder(result)() == 3 );
	result = cache.lookup("www.esoft.com/gamma/delta");
	BOOST_CHECK( category_decoder(result)() == 4 );
	//cout << cache << '\n';
}

struct domain_generator {
	static const char* tld[];
	static const size_t tld_count;
	int i;
	string operator()()
	{
		++i;
		ostringstream os;
		os<<i<<'.'<<"domain-"<<i<<'.'<<tld[i%tld_count];
		return os.str();
	}
	domain_generator() : i(0) {}
};
const char * domain_generator::tld[] = {"com", "org", "net", "edu", "gov", "mil", "com.uk"};
const size_t domain_generator::tld_count = sizeof(tld)/sizeof(tld[0]);

struct path_generator {
	int i;
	path_generator() : i(0) {}
	string operator()()
	{
		++i;
		ostringstream os;
		for(int j=0; j<(i%10)+1; ++j) {
			os << '/'<<i;
		}
		return os.str();
	}
};

BOOST_AUTO_TEST_CASE( url_cache_much )
{
	cout << __func__ << endl;
	url_cache cache;
	vector<string> domains(30);
	vector<string> paths(10);
	unsigned i;
	info_t ival;
	info_t result;
	time_t now( time(0) );

	generate(domains.begin(), domains.end(), domain_generator());
	generate(paths.begin(), paths.end(), path_generator());

	i = 1;
	for(vector<string>::iterator ds=domains.begin(); ds<domains.end(); ++ds) {
		for(vector<string>::iterator ps=paths.begin(); ps<paths.end(); ++ps) {
			(category_encoder(ival))(++i);
			cache.insert(*ds + *ps, ival, now);
		}
	}
	i = 1;
	for(vector<string>::iterator ds=domains.begin(); ds<domains.end(); ++ds) {
		for(vector<string>::iterator ps=paths.begin(); ps<paths.end(); ++ps) {
			result = cache.lookup(*ds + *ps);
			BOOST_CHECK( category_decoder(result)() == ++i );
		}
	}
	//cout << cache;
	cout << "path entry size:   " << sizeof(path_entry_t) << '\n';
	cout << "domain entry size: " << sizeof(domain_entry_t) << '\n';
	cout << "Memory used:  " << memory_limiter::used() << '\n';
	cout << "Memory limit: " << memory_limiter::limit() << '\n';
	cout << "Memory used per path: " << (memory_limiter::used() / 300) << '\n';
	cout << '\n';
}

BOOST_AUTO_TEST_CASE( url_cache_lookup_sub )
{
	cout << __func__ << endl;
	url_cache cache;
	vector<string> domains(30);
	vector<string> paths(10);
	unsigned i;
	info_t ival;
	info_t result;
	time_t now( time(0) );

	generate(domains.begin(), domains.end(), domain_generator());
	generate(paths.begin(), paths.end(), path_generator());

	i = 1;
	for(vector<string>::iterator ds=domains.begin(); ds<domains.end(); ++ds) {
		for(vector<string>::iterator ps=paths.begin(); ps<paths.end(); ++ps) {
			(category_encoder(ival))(++i);
			cache.insert(
				string(*ds, ds->find('.')+1)
				+ string(*ps, 0, max<size_t>(ps->rfind('/'), 1)),
				ival,
				now
			);
		}
	}
	i = 1;
	for(vector<string>::iterator ds=domains.begin(); ds<domains.end(); ++ds) {
		for(vector<string>::iterator ps=paths.begin(); ps<paths.end(); ++ps) {
			result = cache.lookup(*ds + *ps);
			BOOST_CHECK( category_decoder(result)() == ++i );
		}
	}
}

BOOST_AUTO_TEST_CASE( url_cache_expire )
{
	cout << __func__ << endl;
	url_cache cache;
	vector<string> domains(5);
	vector<string> paths(10);
	unsigned count;
	info_t ival;
	info_t result;
	const time_t now = time(0);

	generate(domains.begin(), domains.end(), domain_generator());
	generate(paths.begin(), paths.end(), path_generator());

	count = 1;
	for(vector<string>::iterator ds=domains.begin(); ds<domains.end(); ++ds) {
		for(vector<string>::iterator ps=paths.begin(); ps<paths.end(); ++ps) {
			(category_encoder(ival))(count);
			cache.insert(*ds + *ps, ival, now - count);
			++count;
		}
	}

	BOOST_CHECK( cache.get_domains().size() == 5 );
	cout << "After insert\n";
	//cout << cache;
	cout << right << setfill(' ');
	cout << "cache domains: " << setw(8) << cache.get_domains().size() << '\n';

	// Remove it all
	cache.clean_expired( now );
	BOOST_CHECK( cache.get_domains().size() == 0 );
	cout << "After clean_expired all\n";
	//cout << cache;

	count = 1;
	for(vector<string>::iterator ds=domains.begin(); ds<domains.end(); ++ds) {
		for(vector<string>::iterator ps=paths.begin(); ps<paths.end(); ++ps) {
			(category_encoder(ival))(count);
			cache.insert(*ds + *ps, ival, now - count);
			++count;
		}
	}

	// Remove half

	cache.clean_expired( now - 25 );
	BOOST_CHECK( cache.get_domains().size() == 3 );
	cout << "After clean_expired half\n";
	//cout << cache;

	count = 1;
	for(vector<string>::iterator ds=domains.begin(); ds<domains.end(); ++ds) {
		for(vector<string>::iterator ps=paths.begin(); ps<paths.end(); ++ps) {
			result = cache.lookup(*ds + *ps);
			if (count<=25)
				BOOST_CHECK( category_decoder(result)() == count );
			else
				BOOST_CHECK( category_decoder(result)() == 0 );
			++count;
		}
	}

	cout << endl;
}

#if 1
BOOST_AUTO_TEST_CASE( url_cache_dict )
{
	cout << __func__ << endl;
	time_t now( time(0) );
	url_cache cache;
	memory_limiter::limit(1*1024*1024);

	char buffer[256];
	size_t count = 1;
	size_t last_clean = 0;
	info_t ival;
	ifstream words("dict-words");
	BOOST_REQUIRE( words );

	while( count < 100000 && words.getline(buffer, sizeof(buffer)) ) {
		for(size_t i=0; buffer[i] != 0; i++) { buffer[i] = tolower(buffer[i]); }
		(category_encoder(ival))(count);
		try {
			cache.insert(buffer, ival, now);
		} catch( std::bad_alloc ) {
			cache.clean_oldest_n(1000);
cout << "count="<<count<<" inserted before clean="<<(count-last_clean)<<endl;
			last_clean = count;
			cache.insert(buffer, ival, now);
		}
		count++;
	}
	cout << right << setfill(' ');
	cout << "count is       " << setw(8) << count << '\n';
	cout << "cache domains: " << setw(8) << cache.get_domains().size() << '\n';
	cout << "Memory used:   " << setw(8) << memory_limiter::used() << '\n';
	cout << "Memory limit:  " << setw(8) << memory_limiter::limit() << '\n';
	cout << "Memory used per path: " << (memory_limiter::used() / cache.get_domains().size()) << '\n';

	cache.clean_expired( time(0)-1 );
	cout << "After clean:\n";
	cout << "cache domains: " << setw(8) << cache.get_domains().size() << '\n';
	cout << "Memory used:   " << setw(8) << memory_limiter::used() << '\n';
	cout << endl;
}

BOOST_AUTO_TEST_CASE( url_cache_collision )
{
	cout << __func__ << endl;
	time_t now( time(0) );
	url_cache cache;
	memory_limiter::limit(1*1024*1024);

	char buffer[256];
	size_t count = 1;
	info_t ival;
	ifstream words("dict-words");
	BOOST_REQUIRE( words );

	while( count < 100000 && words.getline(buffer, sizeof(buffer)) ) {
		for(size_t i=0; buffer[i] != 0; i++) { buffer[i] = tolower(buffer[i]); }
		(category_encoder(ival))(count);
		try {
			cache.insert(buffer, ival, now);
		} catch( std::bad_alloc ) {
			break;
		}
		count++;
	}
	cout << right << setfill(' ');
	cout << "count is       " << setw(8) << count << '\n';
	cout << "cache domains: " << setw(8) << cache.get_domains().size() << '\n';
	cout << "Collisions:    " << setw(8) << (count - cache.get_domains().size()) << '\n';
	cout << "Memory used:   " << setw(8) << memory_limiter::used() << '\n';
	cout << "Memory limit:  " << setw(8) << memory_limiter::limit() << '\n';
	cout << "Memory used per path: " << (memory_limiter::used() / count) << '\n';
	cout << endl;
}
#endif
