/* Copyright 2008 eSoft, Inc.
 * All Rights Reserved.
 * Licensed under the terms of the eSoft SiteFilter Cache Reference EULA.
 *
 * This code uses the UDNS library.
 * For more information see: http://www.corpit.ru/mjt/udns.html
 */

#ifndef DIA_CACHE_H
#define DIA_CACHE_H

#include "cache.h"
#include "dia.h"

namespace eSoft {

class cached_dia : public url_cache, public dia {
	public:
	cached_dia(
		const std::string& key,
		const std::string& serial,
		const std::string& host
	) : dia(key, serial, host)
	{}
	virtual ~cached_dia()
	{}

	virtual info_t lookup( const std::string &url ) = 0;

	int wait(unsigned timeout)
	{ return dia::wait(0, 0, timeout); }

	int wait(pollfd *pfds, unsigned nfds, unsigned timeout)
	{ return dia::wait(pfds, nfds, timeout); }

	void cache_results(url_cache &cache);
};

// The async class does not wait for DNS responses.
// Instead it returns 0 (uncategorized) or the best known category
// from cache while performing DIA lookup in the background.
// Use this when you do not want to hold up a single-threaded
// process and performance is more important than categorization
// accuracy.
class cached_dia_async : public cached_dia {
public:
	cached_dia_async(
		const std::string& key,
		const std::string& serial,
		const std::string& host
	) : cached_dia(key, serial, host)
	{}

	info_t lookup( const std::string &url );
};

// The sync class waits for DNS responses.
// Use this when categorization accuracy is most important.
class cached_dia_sync : public cached_dia {
private:
	unsigned wait_secs; // number of seconds to wait for a response.
public:
	cached_dia_sync(
		const std::string& key,
		const std::string& serial,
		const std::string& host,
		unsigned wait_secs
	) : cached_dia(key, serial, host), wait_secs(wait_secs)
	{}

	info_t lookup( const std::string &url );
};

};
#include "dia-cache.hpp"
#endif
