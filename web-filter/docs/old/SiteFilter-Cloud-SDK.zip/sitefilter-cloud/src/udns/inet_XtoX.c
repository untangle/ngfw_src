#include "inet_XtoX.h"

#ifdef _WIN32
#include <winsock2.h>
#endif

char *inet_ntop(int af, const void *src, char *dst, size_t dst_len)
{
		const char *a;

		if( af != AF_INET ) {
			return NULL;
		}
		a = inet_ntoa(*(struct in_addr*)src);
		if( !a ) {
			return NULL;
		}
		if( strlen(a) >= dst_len ) {
			return NULL;
		}
		return strncpy(dst, a, dst_len);
}

int inet_pton(int af, const char *src, void *dst)
{
	unsigned long addr = inet_addr(src);
	((struct in_addr*)dst)->s_addr = addr;
	return 1;
}