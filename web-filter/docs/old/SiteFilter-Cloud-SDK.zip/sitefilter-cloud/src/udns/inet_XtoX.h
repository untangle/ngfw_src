#ifndef INET_XTOX_H
#define INET_XTOX_H

#ifdef __cplusplus
extern "C" {
#endif
#include <stdlib.h>

extern char *inet_ntop(int af, const void *src, char *dst, size_t dst_len);
extern int inet_pton(int af, const char *src, void *dst);

#ifdef __cplusplus
};
#endif

#endif