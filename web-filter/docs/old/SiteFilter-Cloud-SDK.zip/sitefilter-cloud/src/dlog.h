#ifndef DLOG_H
#define DLOG_H

#if 0
#include <iomanip>
#include <iostream>
//#define __func__ __FUNCTION__
#define DLOG(x) do { dlog(__func__, x); } while(0)
#define DLOG1(x) do { dlog(__func__, #x, x); } while(0)
#define DLOG2(x,y) do { dlog(__func__, #x, x, #y, y); } while(0)
inline void dlog(const char *func_s, const char * msg)
{
	using namespace std;
	cerr.setf(ios::left, ios::adjustfield);
	cerr << setw(20) << func_s << msg << endl;
}
template<class T>
inline void dlog(const char *func_s, const char * x_s, const T& x)
{
	using namespace std;
	cerr.setf(ios::left, ios::adjustfield);
	cerr << setw(20) << func_s << x_s << '=' << x << endl;
}
template<class T, class U>
inline void dlog(const char *func_s, const char * x_s, const T& x, const char *y_s, const U& y)
{
	using namespace std;
	cerr.setf(ios::left, ios::adjustfield);
	cerr << setw(20) << func_s << x_s << '=' << x << ' ' << y_s << '=' << y << endl;
}
#else
#define DLOG(x)
#define DLOG1(x)
#define DLOG2(x,y)
#endif

#endif
